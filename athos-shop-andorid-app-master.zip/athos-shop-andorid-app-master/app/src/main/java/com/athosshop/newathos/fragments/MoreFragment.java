package com.athosshop.newathos.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.athosshop.newathos.R;
import com.athosshop.newathos.activities.ChangePasswordActivity;
import com.athosshop.newathos.activities.LoginActivity;
import com.athosshop.newathos.utils.UserSessionManager;

public class MoreFragment extends Fragment implements OnClickListener {
    RelativeLayout rl_privacy_policy;
    RelativeLayout rl_quality_measures;
    RelativeLayout rl_terms_conditions;
    RelativeLayout rl_why_choose_us;
    RelativeLayout rl_logout;
    RelativeLayout rl_change_password;
    UserSessionManager sessionManager;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_more, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI(view);
    }

    void initUI(View view) {
        sessionManager=new UserSessionManager(getActivity());
        this.rl_privacy_policy = (RelativeLayout) view.findViewById(R.id.rl_privacy_policy);
        this.rl_terms_conditions = (RelativeLayout) view.findViewById(R.id.rl_terms_conditions);
        this.rl_why_choose_us = (RelativeLayout) view.findViewById(R.id.rl_why_choose_us);
        this.rl_quality_measures = (RelativeLayout) view.findViewById(R.id.rl_quality_measures);
        rl_logout=view.findViewById(R.id.rl_logout);
        rl_change_password=view.findViewById(R.id.rl_change_password);
        this.rl_privacy_policy.setOnClickListener(this);
        this.rl_terms_conditions.setOnClickListener(this);
        this.rl_why_choose_us.setOnClickListener(this);
        this.rl_quality_measures.setOnClickListener(this);
        rl_logout.setOnClickListener(this);
        rl_change_password.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rl_privacy_policy:
                openLink("https://www.athosshop.com/privacy_policy");
                return;
            case R.id.rl_quality_measures:
                openLink("https://www.google.com/");
                return;
            case R.id.rl_terms_conditions:
                openLink("https://www.athosshop.com/term_condition");
                return;
            case R.id.rl_why_choose_us:
                openLink("https://www.athosshop.com/");
                return;
            case R.id.rl_logout:
                sessionManager.clearSession();
                startActivity(new Intent(getActivity(), LoginActivity.class));
                return;
            case R.id.rl_change_password:
                startActivity(new Intent(getActivity(), ChangePasswordActivity.class));
            default:
                return;
        }
    }

    void openLink(String link) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(link)));
    }
}
