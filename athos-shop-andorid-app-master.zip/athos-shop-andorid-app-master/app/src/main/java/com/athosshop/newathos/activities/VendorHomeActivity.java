package com.athosshop.newathos.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.BottomNavigationView.OnNavigationItemSelectedListener;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.fragments.VendorHomeFragment;
import com.athosshop.newathos.fragments.VendorNewItemFragment;
import com.athosshop.newathos.fragments.VendorOrdersFragment;
import com.athosshop.newathos.fragments.VendorProfileFragment;
import com.athosshop.newathos.utils.BottomNavigationViewHelper;
import com.athosshop.newathos.utils.UserSessionManager;

public class VendorHomeActivity extends AppCompatActivity implements OnNavigationItemSelectedListener {
    int backButtonCount = 0;
    UserSessionManager sessionManager;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_home);
        this.sessionManager = new UserSessionManager(this);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(this);
        loadFragment(new VendorHomeFragment());
        getSupportActionBar().setTitle("Home");
        BottomNavigationViewHelper.disableShiftMode(navigation);
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment == null) {
            return false;
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
        return true;
    }

    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        int itemId = item.getItemId();
        if (itemId == R.id.add_item) {
            fragment = new VendorNewItemFragment();
            getSupportActionBar().setTitle("Add Item");
        } else if (itemId == R.id.home) {
            fragment = new VendorHomeFragment();
            getSupportActionBar().setTitle("Home");
        } else if (itemId == R.id.profile) {
            fragment = new VendorProfileFragment();
            getSupportActionBar().setTitle("Profile");
        } else if (itemId == R.id.vendor_orders) {
            fragment = new VendorOrdersFragment();
            getSupportActionBar().setTitle("Orders");
        }

        return loadFragment(fragment);
    }

    public void onBackPressed() {
        if (this.backButtonCount >= 1) {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return;
        }
        Toast.makeText(this, "Press Back button Again.", Toast.LENGTH_SHORT).show();
        this.backButtonCount++;
    }
}
