package com.athosshop.newathos.adapters;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.athosshop.newathos.activities.EditProductDetailsActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.athosshop.newathos.R;
import com.athosshop.newathos.activities.VendorProductsListActivity;
import com.athosshop.newathos.models.GeneralOutput;
import com.athosshop.newathos.models.ItemData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VendorItemListAdapter extends ArrayAdapter<ItemData> {
    API api;
    ArrayList<ItemData> data;
    int layoutResourceId;
    Context mContext;

    public VendorItemListAdapter(Context mContext, int layoutResourceId, ArrayList<ItemData> data) {
        super(mContext, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.mContext = mContext;
        this.data = data;
        this.api = GlobalMethods.getAPI(mContext);
    }

    @NonNull
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            try {
                convertView = ((Activity) this.mContext).getLayoutInflater().inflate(this.layoutResourceId, parent, false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        final ItemData objectItem = (ItemData) this.data.get(position);
        ImageView iv_item_image = (ImageView) convertView.findViewById(R.id.iv_item_image);
        TextView tv_itemname = (TextView) convertView.findViewById(R.id.tv_itemname);
//        TextView tv_itemdes = (TextView) convertView.findViewById(R.id.item_des);
        TextView tv_itemprice = (TextView) convertView.findViewById(R.id.tv_itemprice);
        TextView tv_status = (TextView) convertView.findViewById(R.id.tv_status);
        ImageButton btn_delete = (ImageButton) convertView.findViewById(R.id.btn_delete);
        RelativeLayout rl_mainLayout = convertView.findViewById(R.id.rl_mainLayout);

        iv_item_image.setImageResource(objectItem.getImage());
        tv_itemname.setText(objectItem.getProduct_name());
//        tv_itemdes.setText(objectItem.getDescription());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Rs. ");
        stringBuilder.append(objectItem.getPrice());
        stringBuilder.append("/-");
        tv_itemprice.setText(stringBuilder.toString());
        if (objectItem.getProduct_image() != null) {
            RequestManager with = Glide.with(this.mContext);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(GlobalMethods.BaseUrl);
            stringBuilder2.append(objectItem.getProduct_image());
            with.load(stringBuilder2.toString()).placeholder(R.drawable.demo).dontAnimate().into(iv_item_image);
        }
        if (objectItem.getSold() == 1) {
            tv_status.setText("Sold");
            tv_status.setTextColor(Color.parseColor("#00b9d2"));
        }
        if (objectItem.getProduct_status() == 2) {
            tv_status.setText("Approved");
            tv_status.setTextColor(Color.parseColor("#3ec15f"));
        } else if (objectItem.getProduct_status() == 3) {
            tv_status.setText("Rejected");
            tv_status.setTextColor(Color.parseColor("#ef2425"));
        } else if (objectItem.getProduct_status() == 1) {
            tv_status.setText("Pending");
            tv_status.setTextColor(Color.parseColor("#fda900"));
        }
        btn_delete.setOnClickListener(new OnClickListener() {

            /* renamed from: com.romilandroid.athos.adapters.VendorItemListAdapter$1$1 */
            class C07691 implements DialogInterface.OnClickListener {
                C07691() {
                }

                public void onClick(DialogInterface dialog, int whichButton) {
                    VendorItemListAdapter.this.deleteProduct(objectItem.getProduct_id(), position);
                }
            }

            public void onClick(View v) {
                new Builder(VendorItemListAdapter.this.mContext).setTitle("Profile").setMessage("Do you want to delete this product?").setIcon(17301543).setPositiveButton(17039379, new C07691()).setNegativeButton(17039369, null).show();
            }
        });

        rl_mainLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, EditProductDetailsActivity.class);
                intent.putExtra("ProductId",objectItem.getProduct_id());
                intent.putExtra("ProductTitle", objectItem.getProduct_name());
                intent.putExtra("ProductDescription", objectItem.getDescription());
                intent.putExtra("ProductImage", objectItem.getProduct_image());
                intent.putExtra("ProductPrice", objectItem.getPrice());
                mContext.startActivity(intent);
            }
        });


        return convertView;
    }

    private void deleteProduct(int productId, final int i) {
        try {
            if (GlobalMethods.isConnectedToInternet(this.mContext, false)) {
                GlobalMethods.ShowDialog(this.mContext);
                this.api.delete_product(productId).enqueue(new Callback<GeneralOutput>() {
                    public void onResponse(Call<GeneralOutput> call, Response<GeneralOutput> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            if (VendorProductsListActivity.productAdapter != null) {
                                VendorProductsListActivity.arrayList.remove(i);
                                VendorProductsListActivity.productAdapter.notifyDataSetChanged();
                            }
                            Context context = VendorItemListAdapter.this.mContext;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(" ");
                            stringBuilder.append(((GeneralOutput) response.body()).getMessage());
                            Toast.makeText(context, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
                        }
                        GlobalMethods.hideDialog();
                    }

                    public void onFailure(Call<GeneralOutput> call, Throwable t) {
                        Toast.makeText(VendorItemListAdapter.this.mContext, "There was an error", Toast.LENGTH_SHORT).show();
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
        }
    }
}
