package com.athosshop.newathos.models;

public class LoginOutput {
}
