package com.athosshop.newathos.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;

import com.athosshop.newathos.R;
import com.athosshop.newathos.utils.UserSessionManager;

public class SelectUserTypeActivity extends AppCompatActivity {
    UserSessionManager sessionManager;

    /* renamed from: com.romilandroid.athos.activities.SelectUserTypeActivity$1 */
    class C07461 implements OnClickListener {
        C07461() {
        }

        public void onClick(View v) {
            SelectUserTypeActivity.this.sessionManager.setUserType(2);
            SelectUserTypeActivity.this.startActivity(new Intent(SelectUserTypeActivity.this.getApplicationContext(), HomeActivity.class));
        }
    }

    /* renamed from: com.romilandroid.athos.activities.SelectUserTypeActivity$2 */
    class C07472 implements OnClickListener {
        C07472() {
        }

        public void onClick(View v) {
            SelectUserTypeActivity.this.sessionManager.setUserType(1);
            SelectUserTypeActivity selectUserTypeActivity = SelectUserTypeActivity.this;
            selectUserTypeActivity.startActivity(new Intent(selectUserTypeActivity.getApplicationContext(), HomeActivity.class));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_select_user_type);
        getSupportActionBar().hide();
        initUI();
        findViewById(R.id.vendor).setOnClickListener(new C07461());
        findViewById(R.id.customer).setOnClickListener(new C07472());
    }

    void initUI() {
        this.sessionManager = new UserSessionManager(this);
    }
}
