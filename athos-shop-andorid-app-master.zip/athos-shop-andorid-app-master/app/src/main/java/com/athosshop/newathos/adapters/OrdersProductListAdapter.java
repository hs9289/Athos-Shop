package com.athosshop.newathos.adapters;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.athosshop.newathos.R;
import com.athosshop.newathos.models.OrderDetails;
import com.athosshop.newathos.utils.UserSessionManager;

import java.util.ArrayList;

public class OrdersProductListAdapter extends ArrayAdapter<OrderDetails.ProductData> {
    ArrayList<OrderDetails.ProductData> data;
    int layoutResourceId;
    Context mContext;
    UserSessionManager sessionManager;

    public OrdersProductListAdapter(Context mContext, int layoutResourceId, ArrayList<OrderDetails.ProductData> data) {
        super(mContext, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.mContext = mContext;
        this.data = data;
        this.sessionManager=new UserSessionManager(mContext);
    }

    @NonNull
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            try {
                convertView = ((Activity) this.mContext).getLayoutInflater().inflate(this.layoutResourceId, parent, false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        OrderDetails.ProductData objectItem = this.data.get(position);


        TextView tv_itemname = (TextView) convertView.findViewById(R.id.tv_itemname);
        TextView tv_price = (TextView) convertView.findViewById(R.id.tv_price);
        TextView tv_quantity = (TextView) convertView.findViewById(R.id.tv_quantity);

        tv_itemname.setText(objectItem.getProduct_name());
        tv_price.setText(String.valueOf(objectItem.getPrice()));
        tv_quantity.setText(String.valueOf(objectItem.getQuantity()));
        return convertView;
    }
}
