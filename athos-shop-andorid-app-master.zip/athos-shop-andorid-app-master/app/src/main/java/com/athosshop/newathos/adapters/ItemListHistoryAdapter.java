package com.athosshop.newathos.adapters;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.athosshop.newathos.R;
import com.athosshop.newathos.models.OrdersData;
import com.athosshop.newathos.utils.UserSessionManager;

import java.util.ArrayList;

public class ItemListHistoryAdapter extends ArrayAdapter<OrdersData> {
    ArrayList<OrdersData> data;
    int layoutResourceId;
    Context mContext;
    UserSessionManager sessionManager;

    public ItemListHistoryAdapter(Context mContext, int layoutResourceId, ArrayList<OrdersData> data) {
        super(mContext, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.mContext = mContext;
        this.data = data;
        this.sessionManager=new UserSessionManager(mContext);
    }

    @NonNull
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            try {
                convertView = ((Activity) this.mContext).getLayoutInflater().inflate(this.layoutResourceId, parent, false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        OrdersData objectItem = (OrdersData) this.data.get(position);
        TextView tv_orderid = (TextView) convertView.findViewById(R.id.tv_orderid);
        TextView tv_totalamount = (TextView) convertView.findViewById(R.id.tv_totalamount);
        TextView tv_numberofItems = (TextView) convertView.findViewById(R.id.tv_numberofItems);
        TextView tv_status = (TextView) convertView.findViewById(R.id.tv_status);
        TextView tv_order_datetime = convertView.findViewById(R.id.tv_order_datetime);
        TextView tv_orderPin = convertView.findViewById(R.id.tv_orderPin);
        TextView tv_paymentType = convertView.findViewById(R.id.tv_paymentType);

        tv_orderid.setText("#"+String.valueOf(objectItem.getId()));

        tv_totalamount.setText(String.valueOf(objectItem.getTotal_amount())+"/-");
        tv_numberofItems.setText(String.valueOf(objectItem.getNumber_of_products()));
        tv_order_datetime.setText(objectItem.getCreated_at());
        tv_orderPin.setText(objectItem.getOrder_pin());

        if (objectItem.getOrder_status() == 1) {
            tv_status.setText("Pending");
            tv_status.setTextColor(this.mContext.getResources().getColor(R.color.blue));
        } else if (objectItem.getOrder_status() == 2) {
            tv_status.setText("Delivered");
            tv_status.setTextColor(this.mContext.getResources().getColor(R.color.green));
        } else if (objectItem.getOrder_status() == 3) {
            tv_status.setText("Cancelled");
            tv_status.setTextColor(this.mContext.getResources().getColor(R.color.red));
        }

        if(objectItem.getOrder_type()==1){
            tv_paymentType.setText("Cash");
        }else if(objectItem.getOrder_type()==2){
            tv_paymentType.setText("Online");
        }else{
            tv_paymentType.setText("NA");
        }




        return convertView;
    }
}
