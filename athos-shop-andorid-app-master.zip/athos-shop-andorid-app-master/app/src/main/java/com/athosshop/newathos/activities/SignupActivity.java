package com.athosshop.newathos.activities;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.dialogs.MyDialogListener;
import com.athosshop.newathos.models.UserData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.MyLocationTracker;
import com.athosshop.newathos.utils.UserSessionManager;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity {
    int PERMISSION_REQUEST;
    API api;
    EditText email;
    EditText fname;
    double lat;
    EditText lname;
    EditText PhoneNumber;
    double lon;
    MyDialogListener listener;
    EditText password;
    UserSessionManager sessionManager;

    /* renamed from: com.romilandroid.athos.activities.SignupActivity$1 */
    class C07481 implements OnClickListener {
        C07481() {
        }

        public void onClick(View v) {
            if (SignupActivity.this.validate()) {
                SignupActivity signupActivity = SignupActivity.this;
                signupActivity.RetroCallForSignup(signupActivity.fname.getText().toString(), SignupActivity.this.lname.getText().toString(), SignupActivity.this.PhoneNumber.getText().toString(), SignupActivity.this.email.getText().toString(), SignupActivity.this.password.getText().toString(), SignupActivity.this.sessionManager.getUserType());
            }
        }
    }

    /* renamed from: com.romilandroid.athos.activities.SignupActivity$2 */
    class C07492 implements OnClickListener {
        C07492() {
        }

        public void onClick(View v) {
            SignupActivity signupActivity = SignupActivity.this;
//            SignupActivity.this.sessionManager.setUserLogin(Boolean.valueOf(true));
            signupActivity.startActivity(new Intent(signupActivity.getApplicationContext(), LoginActivity.class));


        }
    }

    /* renamed from: com.romilandroid.athos.activities.SignupActivity$3 */
    class C07503 implements Callback<UserData> {
        C07503() {
        }

        public void onResponse(Call<UserData> call, Response<UserData> response) {
            if (response.isSuccessful() && response.body() != null) {
                Context context;
                System.out.println("Signed up ---- status --- "+((UserData) response.body()).isStatus());
                if (((UserData) response.body()).isStatus()) {
                    SignupActivity.this.sessionManager.setSignInToken(((UserData) response.body()).getToken());
                    SignupActivity.this.sessionManager.setUserId(((UserData) response.body()).getId());
                    SignupActivity.this.sessionManager.setUserType(((UserData) response.body()).getUser_type());
                    SignupActivity.this.sessionManager.setUserLogin(Boolean.valueOf(true));
                    SignupActivity.this.sessionManager.setUserEmail(((UserData) response.body()).getEmail());
                    SignupActivity.this.sessionManager.setUserMobile(((UserData) response.body()).getMobile());
                    SignupActivity.this.sessionManager.setFirebaseToken(((UserData) response.body()).getFirebase_token());
                    if (((UserData) response.body()).getUser_type() == 1) {
                        context = SignupActivity.this;
                        context.startActivity(new Intent(context, HomeActivity.class));
                    }
                } else if (((UserData) response.body()).getUser_type() == 2) {
                    context = SignupActivity.this;
                    context.startActivity(new Intent(context, VendorHomeActivity.class));
                }

                context = SignupActivity.this.getApplicationContext();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(" ");
                stringBuilder.append(((UserData) response.body()).getMessage());
                Toast.makeText(context, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
            }
            GlobalMethods.hideDialog();
        }

        public void onFailure(Call<UserData> call, Throwable t) {
            Toast.makeText(SignupActivity.this.getApplicationContext(), "There was an error", Toast.LENGTH_SHORT).show();
            GlobalMethods.hideDialog();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        initUI();
        if (isLocationPermissionAllowed()) {
            getLocation();
        } else {
            requestLocationPermission();
        }
        findViewById(R.id.signup).setOnClickListener(new C07481());
        findViewById(R.id.login_text).setOnClickListener(new C07492());
    }

    void initUI() {
        this.fname = (EditText) findViewById(R.id.fname);
        this.lname = (EditText) findViewById(R.id.lname);
        this.PhoneNumber = (EditText) findViewById(R.id.number);
        this.email = (EditText) findViewById(R.id.email);
        this.password = (EditText) findViewById(R.id.password);
        this.sessionManager = new UserSessionManager(this);
        this.api = GlobalMethods.getAPI(this);
    }

    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
    }


    boolean validate() {
        boolean status = true;
        try {
            if (this.fname.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Please Enter First Name", Toast.LENGTH_SHORT).show();
                status = false;
                this.fname.requestFocus();
            }
            if (this.lname.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Please Enter Last Name", Toast.LENGTH_SHORT).show();
                status = false;
                this.lname.requestFocus();
            }
            if (this.email.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Please Enter Your Email", Toast.LENGTH_SHORT).show();
                status = false;
                this.email.requestFocus();
            }

            if (this.PhoneNumber.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Please Enter Your Mobile Number", Toast.LENGTH_SHORT).show();
                status = false;
                this.PhoneNumber.requestFocus();
            }
            if (this.password.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Please Enter password", Toast.LENGTH_SHORT).show();
                status = false;
                this.password.requestFocus();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    public void RetroCallForSignup(String fname, String lname, String email, String num, String password, int usertype) {
        SignupActivity signupActivity = this;
        try {
            if (GlobalMethods.isConnectedToInternet(getApplicationContext(), false)) {
                GlobalMethods.ShowDialog(this);
                signupActivity.api.register_user(fname, lname, email, num, password, usertype, signupActivity.lat, signupActivity.lon).enqueue(new C07503());
            }
        } catch (Exception e) {
        }
    }

    void getLocation() {
        MyLocationTracker myLocationTracker = new MyLocationTracker(getApplicationContext());
        this.lat = myLocationTracker.getLatitude();
        this.lon = myLocationTracker.getLongitude();
        if (this.lat == 0.0d) {
            Location l = myLocationTracker.getLastKnownLocation();
            if (l != null) {
                this.lat = l.getLatitude();
                this.lon = l.getLongitude();
            }
        }
        Log.d("Lat:- ", String.valueOf(this.lat));
        Log.d("Lon:- ", String.valueOf(this.lon));
    }

    private boolean isLocationPermissionAllowed() {
        try {
            int location1 = ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION");
            int location2 = ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION");
            List<String> listPermissionNeeded = new ArrayList();
            if (location1 != 0) {
                listPermissionNeeded.add("android.permission.ACCESS_COARSE_LOCATION");
            }
            if (location2 != 0) {
                listPermissionNeeded.add("android.permission.ACCESS_FINE_LOCATION");
            }
            if (listPermissionNeeded.isEmpty()) {
                return true;
            }
            ActivityCompat.requestPermissions(this, (String[]) listPermissionNeeded.toArray(new String[listPermissionNeeded.size()]), this.PERMISSION_REQUEST);
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private void requestLocationPermission() {
        try {
            ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.ACCESS_COARSE_LOCATION");
            ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.ACCESS_FINE_LOCATION");
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"}, this.PERMISSION_REQUEST);
        } catch (Exception e) {
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == this.PERMISSION_REQUEST){
            getLocation();
        }

    }
}