package com.athosshop.newathos.activities;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.athosshop.newathos.R;
import com.athosshop.newathos.adapters.OrdersProductListAdapter;
import com.athosshop.newathos.models.OrderDetails;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrderDetailActivity extends AppCompatActivity {

    int orderId;
    Context context;
    API api;
    ListView orderItemsListView;
    ArrayList<OrderDetails.ProductData> arrayList=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_order_detail);

        orderId=getIntent().getIntExtra("OrderId",0);
        initUI();
        RetroCallForGetOrdersDetails(orderId);
    }

    void initUI(){
        context=OrderDetailActivity.this;
        api=GlobalMethods.getAPI(context);
        orderItemsListView=findViewById(R.id.orderItemsListView);
    }

    void bindUI(){

    }

    void bindItemList(ArrayList<OrderDetails.ProductData> data){
        arrayList=data;
        orderItemsListView.setAdapter(new OrdersProductListAdapter(context, R.layout.orders_product_list_item, this.arrayList));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    public void RetroCallForGetOrdersDetails(int orderId) {
        try {
            if (GlobalMethods.isConnectedToInternet(context, false)) {
                GlobalMethods.ShowDialog(context);
                api.get_order_details(orderId).enqueue(new Callback<OrderDetails>() {
                    @Override
                    public void onResponse(Call<OrderDetails> call, Response<OrderDetails> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            if(response.body().isStatus()){
                                bindItemList(response.body().getOrderItems());
                            }
                        }
                        GlobalMethods.hideDialog();
                    }

                    @Override
                    public void onFailure(Call<OrderDetails> call, Throwable t) {
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
            GlobalMethods.hideDialog();
        }
    }
}
