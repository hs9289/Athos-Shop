package com.athosshop.newathos.fragments;

import android.annotation.TargetApi;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.models.Category;
import com.athosshop.newathos.models.GeneralOutput;
import com.athosshop.newathos.models.ItemData;
import com.athosshop.newathos.models.SubCategory;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.UserSessionManager;
import com.yalantis.ucrop.util.BitmapLoadUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import okhttp3.MediaType;
import okhttp3.MultipartBody.Part;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.yalantis.ucrop.util.FileUtils.getDataColumn;
import static com.yalantis.ucrop.util.FileUtils.isDownloadsDocument;
import static com.yalantis.ucrop.util.FileUtils.isExternalStorageDocument;
import static com.yalantis.ucrop.util.FileUtils.isGooglePhotosUri;
import static com.yalantis.ucrop.util.FileUtils.isMediaDocument;

public class VendorNewItemFragment extends Fragment {
    int CAMERA_REQUEST_CODE = 10;
    int GALLERY_REQUEST_CODE = 20;
    int REQUEST_CODE = 40;
    int RESULT_CROP = 30;
    ArrayAdapter<String> adapter_categories;
    ArrayAdapter<String> adapter_subcategories;
    API api;
    ArrayList<String> categoriesList = new ArrayList();
    Spinner category;
    Context context;
    EditText description;
    String fileManagerString;
    File folder;
    Bitmap imageBitmap;
    String imageFilePath;
    String imagePath;
    boolean imageStatus = false;
    Button image_upload;
    File output;
    EditText price;
    EditText product_name;
    String selectedImagePath;
    UserSessionManager sessionManager;
    ArrayList<String> subCategoriesList = new ArrayList();
    Spinner subcategory;
    Button submit;
    TextView text_upload_image;

    /* renamed from: com.romilandroid.athos.fragments.VendorNewItemFragment$1 */
    class C07861 implements OnClickListener {
        C07861() {
        }

        public void onClick(View v) {
            if (VendorNewItemFragment.this.isPermissionAllowed()) {
                VendorNewItemFragment.this.showDiloag();
            } else {
                VendorNewItemFragment.this.requestPermission();
            }
        }
    }

    /* renamed from: com.romilandroid.athos.fragments.VendorNewItemFragment$2 */
    class C07872 implements OnClickListener {
        C07872() {
        }

        public void onClick(View v) {
            if (VendorNewItemFragment.this.validate()) {
                ItemData itemData = new ItemData(VendorNewItemFragment.this.sessionManager.getUserId(), VendorNewItemFragment.this.product_name.getText().toString(), GlobalMethods.getCategoryIdByName(VendorNewItemFragment.this.category.getSelectedItem().toString()), GlobalMethods.getSubCategoryIdByName(VendorNewItemFragment.this.subcategory.getSelectedItem().toString()), VendorNewItemFragment.this.description.getText().toString(), Float.parseFloat(VendorNewItemFragment.this.price.getText().toString()));
                VendorNewItemFragment vendorNewItemFragment = VendorNewItemFragment.this;
                vendorNewItemFragment.RetroCallForUploadNewItem(vendorNewItemFragment.selectedImagePath, itemData);
            }
        }
    }

    /* renamed from: com.romilandroid.athos.fragments.VendorNewItemFragment$3 */
    class C07883 implements OnItemSelectedListener {
        C07883() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
            if (position != 0) {
                VendorNewItemFragment.this.getSubCategoryList(((Category) GlobalMethods.categoriesList.get(position - 1)).getId());
            }
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }


    /* renamed from: com.romilandroid.athos.fragments.VendorNewItemFragment$5 */
    class C07905 implements DialogInterface.OnClickListener {
        C07905() {
        }

        public void onClick(DialogInterface dialog, int which) {
            switch (which) {
                case 0:
                    VendorNewItemFragment.this.openCamera();
                    return;
                case 1:
                    VendorNewItemFragment.this.pickGalleryImage();
                    return;
                default:
                    return;
            }
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_vendor_new_item, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI(view);
        getCategoryList();
        getSubCategoryList(0);
        bindSpinners();
        this.image_upload.setOnClickListener(new C07861());
        this.submit.setOnClickListener(new C07872());
        this.category.setOnItemSelectedListener(new C07883());
    }

    void initUI(View view) {
        this.context = getActivity();
        this.api = GlobalMethods.getAPI(getActivity());
        this.sessionManager = new UserSessionManager(getActivity());
        this.category = (Spinner) view.findViewById(R.id.category);
        this.subcategory = (Spinner) view.findViewById(R.id.subcategory);
        this.submit = (Button) view.findViewById(R.id.submit);
        this.image_upload = (Button) view.findViewById(R.id.image_upload);
        this.text_upload_image = (TextView) view.findViewById(R.id.text_upload_image);
        this.product_name = (EditText) view.findViewById(R.id.product_name);
        this.price = (EditText) view.findViewById(R.id.price);
        this.description = (EditText) view.findViewById(R.id.description);
    }

    boolean validate() {
        if (this.product_name.getText().toString().isEmpty()) {
            Toast.makeText(getActivity(), "Please Enter product name", Toast.LENGTH_SHORT).show();
            this.product_name.requestFocus();
            return false;
        } else if (this.description.getText().toString().isEmpty()) {
            Toast.makeText(getActivity(), "Please Enter product description", Toast.LENGTH_SHORT).show();
            this.description.requestFocus();
            return false;
        } else if (this.price.getText().toString().isEmpty()) {
            Toast.makeText(getActivity(), "Please Enter product price", Toast.LENGTH_SHORT).show();
            this.price.requestFocus();
            return false;
        } else if (this.category.getSelectedItem().toString().equals("Category")) {
            Toast.makeText(getActivity(), "Please Select product category", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!this.subcategory.getSelectedItem().toString().equals("SubCategory")) {
            return true;
        } else {
            Toast.makeText(getActivity(), "Please Select product sub category", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    void bindSpinners() {
        this.adapter_categories = new ArrayAdapter(getActivity(), R.layout.vendor_spinner_layout, this.categoriesList);
        this.adapter_categories.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.category.setAdapter(this.adapter_categories);
        this.adapter_subcategories = new ArrayAdapter(getActivity(), R.layout.vendor_spinner_layout, this.subCategoriesList);
        this.adapter_subcategories.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.subcategory.setAdapter(this.adapter_subcategories);
    }

    void getCategoryList() {
        this.categoriesList.add("Category");
        if (GlobalMethods.categoriesList.size() > 0) {
            for (int i = 0; i < GlobalMethods.categoriesList.size(); i++) {
                this.categoriesList.add(((Category) GlobalMethods.categoriesList.get(i)).getCategory_name());
            }
        }
    }

    void getSubCategoryList(int cid) {
        this.subCategoriesList.clear();
        this.subCategoriesList.add("SubCategory");
        if (GlobalMethods.subCategoriesList.size() > 0) {
            for (int i = 0; i < GlobalMethods.subCategoriesList.size(); i++) {
                SubCategory category = (SubCategory) GlobalMethods.subCategoriesList.get(i);
                if (category.getCid() == cid) {
                    this.subCategoriesList.add(category.getCategory());
                }
            }
        }
        ArrayAdapter arrayAdapter = this.adapter_subcategories;
        if (arrayAdapter != null) {
            arrayAdapter.notifyDataSetChanged();
        }
    }

    public void RetroCallForUploadNewItem(String imagePath, ItemData itemData) {
        try {
            if (GlobalMethods.isConnectedToInternet(this.context, false)) {
                GlobalMethods.ShowDialog(this.context);
                Part iFile = null;
                if (imagePath != null) {
                    File imageFile = new File(imagePath);
                    iFile = Part.createFormData("image", imageFile.getName(), RequestBody.create(MediaType.parse("image/*"), imageFile));
                }

                RequestBody supplier_id = RequestBody.create(MediaType.parse("multipart/form-data"),String.valueOf(itemData.getSupplier_id()));
                RequestBody product_name1 = RequestBody.create(MediaType.parse("multipart/form-data"),itemData.getProduct_name());
                RequestBody category1 = RequestBody.create(MediaType.parse("multipart/form-data"),String.valueOf(itemData.getCategory()));
                RequestBody sub_category = RequestBody.create(MediaType.parse("multipart/form-data"),String.valueOf(itemData.getSub_category()));
                RequestBody description1 = RequestBody.create(MediaType.parse("multipart/form-data"),String.valueOf(itemData.getDescription()));
                RequestBody price1 = RequestBody.create(MediaType.parse("multipart/form-data"),String.valueOf(itemData.getPrice()));


                this.api.add_new_item(iFile, supplier_id,product_name1,category1,sub_category,description1,price1).enqueue(new Callback<GeneralOutput>() {
                    public void onResponse(Call<GeneralOutput> call, Response<GeneralOutput> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            if (response.body().isStatus()) {
                                selectedImagePath = null;
                                text_upload_image.setText("");
                                product_name.setText("");
                                description.setText("");
                                price.setText("");
                                category.setSelection(0);
                                subcategory.setSelection(0);
                                context.startActivity(getActivity().getIntent());
                            }
                        }
                        GlobalMethods.hideDialog();
                    }

                    public void onFailure(Call<GeneralOutput> call, Throwable t) {
                        Toast.makeText(VendorNewItemFragment.this.context, "There was an error", Toast.LENGTH_SHORT).show();
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showDiloag() {
        try {
            Dialog dialog = new Dialog(getActivity());
            Builder builder = new Builder(getActivity());
            builder.setTitle("Select Image");
            builder.setItems(new CharSequence[]{"Camera", "Gallery"}, new C07905());
            builder.show();
            dialog.dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == this.CAMERA_REQUEST_CODE) {
                getActivity();
                if (resultCode == -1) {
                    Options options;
                    this.selectedImagePath = getPath(this.context, Uri.fromFile(this.output));
                    //performCrop(this.selectedImagePath);
                    if (this.selectedImagePath != null) {
                        try {
                            options = new Options();
                            options.inSampleSize = 8;
                            this.imageBitmap = BitmapFactory.decodeFile(this.selectedImagePath, options);
                            BitmapFactory.decodeFile(this.selectedImagePath, options);
                        } catch (Exception e) {
                            e.getMessage();
                        }
                    } else {
                        Toast.makeText(this.context, "There was an error", Toast.LENGTH_SHORT).show();
                    }

                }
            }

            if (requestCode == this.GALLERY_REQUEST_CODE) {
                if (resultCode == -1) {
                    Uri selectedImageUri = data.getData();
                    this.selectedImagePath = getPath(this.context, selectedImageUri);
                    //this.fileManagerString = selectedImageUri.getPath();

                }
            }

        } catch (Exception e3) {
        }
    }

    public Uri bitmapToUriConverter(Bitmap mBitmap) {
        try {
            Options options = new Options();
            options.inSampleSize = BitmapLoadUtils.calculateInSampleSize(options, 350, 350);
            options.inJustDecodeBounds = false;
            Bitmap newBitmap = Bitmap.createScaledBitmap(mBitmap, 350, 350, true);
            File filesDir = this.context.getFilesDir();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Image");
            stringBuilder.append(new Random().nextInt());
            stringBuilder.append(".jpg");
            File file = new File(filesDir, stringBuilder.toString());
            FileOutputStream out = this.context.openFileOutput(file.getName(), 0);
            newBitmap.compress(CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
            return Uri.fromFile(new File(file.getAbsolutePath()));
        } catch (Exception e) {
            Log.e("Message", e.getMessage());
            return null;
        }
    }

    private void performCrop(String picUri) {
        try {
            Intent cropIntent = new Intent("com.android.camera.action.CROP");
            File f = new File(picUri);
            Uri contentUri = Uri.fromFile(f);
            //Uri photoURI = this.context;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.context.getPackageName());
            stringBuilder.append(".provider");
            cropIntent.setDataAndType(FileProvider.getUriForFile(this.context, stringBuilder.toString(), f), "image/*");
            cropIntent.putExtra("crop", "true");
            cropIntent.putExtra("aspectX", 1);
            cropIntent.putExtra("aspectY", 1);
            cropIntent.putExtra("outputX", 350);
            cropIntent.putExtra("outputY", 350);
            cropIntent.putExtra("return-data", true);
            //cropIntent.addFlags(3);
            startActivityForResult(cropIntent, this.RESULT_CROP);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this.context, "Device dos not support", Toast.LENGTH_SHORT).show();
        }
    }

    public void pickGalleryImage() {
        try {
            this.imageStatus = true;
            Intent intent;
            if (VERSION.SDK_INT < 19) {
                intent = new Intent();
                intent.setType("image/*");
                intent.setAction("android.intent.action.GET_CONTENT");
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), this.GALLERY_REQUEST_CODE);
            } else {
                intent = new Intent("android.intent.action.OPEN_DOCUMENT");
                intent.addCategory("android.intent.category.OPENABLE");
                intent.setType("image/*");
                startActivityForResult(intent, this.GALLERY_REQUEST_CODE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void openCamera() {
        try {
            this.folder = new File(Environment.getExternalStorageDirectory(), "Courier");
            if (!this.folder.exists()) {
                this.folder.mkdirs();
            }
            this.imageStatus = true;
            Intent intent;
            File file;
            StringBuilder stringBuilder;
            if (VERSION.SDK_INT >= 24) {
                try {
                    intent = new Intent("android.media.action.IMAGE_CAPTURE");
                    file = this.folder;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(String.valueOf(System.currentTimeMillis()));
                    stringBuilder.append(".jpg");
                    this.output = new File(file, stringBuilder.toString());
                    //Uri photoURI = this.context;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(this.context.getPackageName());
                    stringBuilder2.append(".provider");
                    intent.putExtra("output", FileProvider.getUriForFile(this.context, stringBuilder2.toString(), this.output));
                    //intent.addFlags(3);
                    startActivityForResult(intent, this.CAMERA_REQUEST_CODE);
                } catch (Exception e) {
                }
            } else {
                intent = new Intent("android.media.action.IMAGE_CAPTURE");
                file = this.folder;
                stringBuilder = new StringBuilder();
                stringBuilder.append(String.valueOf(System.currentTimeMillis()));
                stringBuilder.append(".jpg");
                this.output = new File(file, stringBuilder.toString());
                intent.putExtra("output", Uri.fromFile(this.output));
                startActivityForResult(intent, this.CAMERA_REQUEST_CODE);
            }
        } catch (Exception e2) {
        }
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public String getPath(final Context context, final Uri uri) {
        try{
            final boolean isKitKat = Build.VERSION.SDK_INT >= 19;
            if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
                // ExternalStorageProvider
                if (isExternalStorageDocument(uri)) {
                    final String docId = DocumentsContract.getDocumentId(uri);
                    final String[] split = docId.split(":");
                    final String type = split[0];

                    if ("primary".equalsIgnoreCase(type)) {
                        return Environment.getExternalStorageDirectory() + "/" + split[1];
                    }

                    // TODO handle non-primary volumes
                }
                // DownloadsProvider
                else if (isDownloadsDocument(uri)) {

                    final String id = DocumentsContract.getDocumentId(uri);
                    final Uri contentUri = ContentUris.withAppendedId(
                            Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                    return getDataColumn(context, contentUri, null, null);
                }
                // MediaProvider
                else if (isMediaDocument(uri)) {
                    final String docId = DocumentsContract.getDocumentId(uri);
                    final String[] split = docId.split(":");
                    final String type = split[0];

                    Uri contentUri = null;
                    if ("image".equals(type)) {
                        contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    } else if ("video".equals(type)) {
                        contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    } else if ("audio".equals(type)) {
                        contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    }
                    final String selection = "_id=?";
                    final String[] selectionArgs = new String[]{
                            split[1]
                    };
                    return getDataColumn(context, contentUri, selection, selectionArgs);
                }
            }
            // MediaStore (and general)
            else if ("content".equalsIgnoreCase(uri.getScheme())) {
                // Return the remote address
                if (isGooglePhotosUri(uri))
                    return uri.getLastPathSegment();
                return getDataColumn(context, uri, null, null);
            }
            // File
            else if ("file".equalsIgnoreCase(uri.getScheme())) {
                return uri.getPath();
            }
        } catch (Exception e) {
            e.printStackTrace();
            //globalMethods.SendErrorReport(e,getActivity());
        }
        return null;
    }

    private boolean isPermissionAllowed() {
        try {
            int camera = ContextCompat.checkSelfPermission(getActivity(), "android.permission.CAMERA");
            int microphone = ContextCompat.checkSelfPermission(getActivity(), "android.permission.RECORD_AUDIO");
            int writestorage = ContextCompat.checkSelfPermission(getActivity(), "android.permission.WRITE_EXTERNAL_STORAGE");
            int readStorage = ContextCompat.checkSelfPermission(getActivity(), "android.permission.READ_EXTERNAL_STORAGE");
            List<String> listPermissionNeeded = new ArrayList();
            if (camera != 0) {
                listPermissionNeeded.add("android.permission.CAMERA");
            }
            if (microphone != 0) {
                listPermissionNeeded.add("android.permission.RECORD_AUDIO");
            }
            if (writestorage != 0) {
                listPermissionNeeded.add("android.permission.READ_EXTERNAL_STORAGE");
            }
            if (readStorage != 0) {
                listPermissionNeeded.add("android.permission.WRITE_EXTERNAL_STORAGE");
            }
            if (listPermissionNeeded.isEmpty()) {
                return true;
            }
            ActivityCompat.requestPermissions(getActivity(), (String[]) listPermissionNeeded.toArray(new String[listPermissionNeeded.size()]), this.REQUEST_CODE);
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private void requestPermission() {
        try {
            ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), "android.permission.CAMERA");
            ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), "android.permission.READ_EXTERNAL_STORAGE");
            ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), "android.permission.WRITE_EXTERNAL_STORAGE");
            ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), "android.permission.RECORD_AUDIO");
            ActivityCompat.requestPermissions(getActivity(), new String[]{"android.permission.CAMERA", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.RECORD_AUDIO"}, this.REQUEST_CODE);
        } catch (Exception e) {
        }
    }
}
