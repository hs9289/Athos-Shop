package com.athosshop.newathos.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.athosshop.newathos.models.Category;
import com.daimajia.slider.library.Indicators.PagerIndicator;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderLayout.Transformer;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.BaseSliderView.OnSliderClickListener;
import com.daimajia.slider.library.SliderTypes.BaseSliderView.ScaleType;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx.OnPageChangeListener;
import com.athosshop.newathos.R;
import com.athosshop.newathos.activities.CartActivity;
import com.athosshop.newathos.adapters.CategoriesListAdapter;
import com.athosshop.newathos.adapters.ItemListAdapter;
import com.athosshop.newathos.models.CommonData;
import com.athosshop.newathos.models.ItemData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.UserSessionManager;

import java.util.ArrayList;
import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment implements OnSliderClickListener, OnPageChangeListener {
    public static API api;
    public static ArrayList<ItemData> arrayList = new ArrayList();
    static CategoriesListAdapter categoriesListAdapter;
    static RecyclerView category_recycler_view;
    public static Context context;
    public static ItemListAdapter product_adapter;
    private SliderLayout mDemoSlider;
    UserSessionManager sessionManager;
    static RecyclerView item_recyclerView;

    /* renamed from: com.romilandroid.athos.fragments.HomeFragment$1 */
    class C07761 implements OnClickListener {
        C07761() {
        }

        public void onClick(View v) {
            HomeFragment homeFragment = HomeFragment.this;
            homeFragment.startActivity(new Intent(homeFragment.getActivity(), CartActivity.class));
        }
    }

    /* renamed from: com.romilandroid.athos.fragments.HomeFragment$2 */
    static class C07772 implements Callback<ArrayList<ItemData>> {
        C07772() {
        }

        public void onResponse(Call<ArrayList<ItemData>> call, Response<ArrayList<ItemData>> response) {
            if (response.isSuccessful() && response.body() != null) {
                HomeFragment.bindUI((ArrayList) response.body());
            }
            GlobalMethods.hideDialog();
        }

        public void onFailure(Call<ArrayList<ItemData>> call, Throwable t) {
            t.printStackTrace();
            Toast.makeText(HomeFragment.context, "There was an error" + t.getMessage(), Toast.LENGTH_SHORT).show();
            GlobalMethods.hideDialog();
        }
    }

    /* renamed from: com.romilandroid.athos.fragments.HomeFragment$3 */
    static class C07783 implements Callback<CommonData> {
        C07783() {
        }

        public void onResponse(Call<CommonData> call, Response<CommonData> response) {
            if (response.isSuccessful() && response.body() != null) {
                Log.d("eeeeeeeeeeeeee", "rrrrrrrrrrr");
                GlobalMethods.commonDataRetrieved = true;
                if (((CommonData) response.body()).getCities() != null && ((CommonData) response.body()).getCities().size() > 0) {
                    GlobalMethods.citiesList = ((CommonData) response.body()).getCities();
                }
                if (((CommonData) response.body()).getLocalities() != null && ((CommonData) response.body()).getLocalities().size() > 0) {
                    GlobalMethods.localitiesList = ((CommonData) response.body()).getLocalities();
                }
                if (((CommonData) response.body()).getCategories() != null && ((CommonData) response.body()).getCategories().size() > 0) {
                    GlobalMethods.categoriesList = ((CommonData) response.body()).getCategories();
                }
                if (((CommonData) response.body()).getSub_categories() != null && ((CommonData) response.body()).getSub_categories().size() > 0) {
                    GlobalMethods.subCategoriesList = ((CommonData) response.body()).getSub_categories();
                }
                HomeFragment.bindCategoriesList();
            }
        }

        public void onFailure(Call<CommonData> call, Throwable t) {
            Toast.makeText(HomeFragment.context, "There was an error", Toast.LENGTH_SHORT).show();
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI(view);
        initSlider(view);
        RetroCallForGetAllProductList(1);
        view.findViewById(R.id.fab_cart).setOnClickListener(new C07761());
        bindCategoriesList();
    }

    void initUI(View view) {
        context = getActivity();
        api = GlobalMethods.getAPI(getActivity());
        this.sessionManager = new UserSessionManager(getActivity());
        item_recyclerView = view.findViewById(R.id.item_recyclerView);
        this.mDemoSlider = (SliderLayout) view.findViewById(R.id.slider);
        category_recycler_view = (RecyclerView) view.findViewById(R.id.category_recycler_view);
    }

    static void bindCategoriesList() {
        if (GlobalMethods.categoriesList.size() > 0) {
            for (Category model : GlobalMethods.categoriesList) {
                System.out.println("Category List --- " + model.getCategory_name());
                System.out.println("Category List --- " + model.getCategory_image());
            }
//            System.out.println("Category List --- "+ GlobalMethods.categoriesList.toString());
            categoriesListAdapter = new CategoriesListAdapter(GlobalMethods.categoriesList, context);
            category_recycler_view.setLayoutManager(new LinearLayoutManager(context, 0, false));
            category_recycler_view.setItemAnimator(new DefaultItemAnimator());
            category_recycler_view.setAdapter(categoriesListAdapter);
        }
    }

    void initSlider(View view) {
        HashMap<String, String> file_maps = new HashMap();
        file_maps.put("Chicken2", "http://www.athosshop.com/images/chicken3.jpg");
//        file_maps.put("Mutton", "http://athosshop.com/images/goats2.jpg");
        file_maps.put("Chicken", "http://www.athosshop.com/images/mainchicken.png");
//        file_maps.put("Paneer", Integer.valueOf(R.drawable.banner4));
        for (String name : file_maps.keySet()) {
            TextSliderView textSliderView = new TextSliderView(getActivity());
            textSliderView.description("")
                    .image((file_maps.get(name)))
                    .setScaleType(ScaleType.CenterCrop).setOnSliderClickListener(this);
            textSliderView.bundle(new Bundle());
            textSliderView.getBundle().putString("extra", name);
            this.mDemoSlider.addSlider(textSliderView);
        }
        this.mDemoSlider.setPresetTransformer(Transformer.Default);
        this.mDemoSlider.setCustomIndicator((PagerIndicator) view.findViewById(R.id.custom_indicator));
        this.mDemoSlider.setDuration(4000);
        this.mDemoSlider.addOnPageChangeListener(this);
    }

    public static void bindUI(ArrayList<ItemData> data) {
        if (data.size() == 0) {
            Toast.makeText(context, "Product not available", Toast.LENGTH_SHORT).show();
        }
        arrayList = data;
        product_adapter = new ItemListAdapter(context, R.layout.item_list_item, arrayList);
        item_recyclerView.setHasFixedSize(true);
        item_recyclerView.setLayoutManager(new LinearLayoutManager(context));
        item_recyclerView.setAdapter(product_adapter);
        item_recyclerView.setNestedScrollingEnabled(false);

        if (!GlobalMethods.commonDataRetrieved) {
            RetroCallForGetCommonData();
        }
    }

    public void onSliderClick(BaseSliderView slider) {
    }

    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    public void onPageSelected(int position) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Page Changed: ");
        stringBuilder.append(position);
        Log.d("Slider Demo", stringBuilder.toString());
    }

    public void onPageScrollStateChanged(int state) {
    }

    public static void justifyListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter adapter = listView.getAdapter();
        if (adapter != null) {
            ViewGroup vg = listView;
            int totalHeight = 0;
            for (int i = 0; i < adapter.getCount(); i++) {
                View listItem = adapter.getView(i, null, vg);
                listItem.measure(0, 0);
                totalHeight += listItem.getMeasuredHeight();
                int oneItemHeight = listItem.getMeasuredHeight();
            }
            LayoutParams par = listView.getLayoutParams();
            par.height = (listView.getDividerHeight() * (adapter.getCount() - 1)) + totalHeight;
            listView.setLayoutParams(par);
            listView.requestLayout();
        }
    }

    public static void RetroCallForGetAllProductList(int category) {
        try {
            if (GlobalMethods.isConnectedToInternet(context, false)) {
                GlobalMethods.ShowDialog(context);
                api.get_all_product_list(category).enqueue(new C07772());
            }
        } catch (Exception e) {
        }
    }

    public static void RetroCallForGetCommonData() {
        try {
            if (GlobalMethods.isConnectedToInternet(context, false)) {
                api.get_all_common_data().enqueue(new C07783());
            }
        } catch (Exception e) {
        }
    }
}
