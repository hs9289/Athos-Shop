package com.athosshop.newathos.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.activities.VendorProductsListActivity;
import com.athosshop.newathos.models.CommonData;
import com.athosshop.newathos.models.ItemData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.UserSessionManager;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VendorHomeFragment extends Fragment implements OnClickListener {
    static API api;
    static Context context;
    int allProducts = 0;
    int approvedProducts = 0;
    ArrayList<ItemData> arrayList = new ArrayList();
    int rejectedProducts = 0;
    RelativeLayout rl_allProducts;
    RelativeLayout rl_approved;
    RelativeLayout rl_products;
    RelativeLayout rl_rejected;
    RelativeLayout rl_pending;
    UserSessionManager sessionManager;
    int pendingProducts = 0;
    TextView tv_all_products;
    TextView tv_approved;
    TextView tv_product;
    TextView tv_rejected;
    TextView tv_pending;


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_vendor_home, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI(view);
        RetroCallForGetVendorAllProductList(this.sessionManager.getUserId());
    }

    void initUI(View view) {
        context = getActivity();
        api = GlobalMethods.getAPI(getActivity());
        this.sessionManager = new UserSessionManager(getActivity());
        this.tv_all_products = (TextView) view.findViewById(R.id.tv_all_products);
        this.tv_product = (TextView) view.findViewById(R.id.tv_product);
        this.tv_pending = (TextView) view.findViewById(R.id.tv_pending);
        this.tv_approved = (TextView) view.findViewById(R.id.tv_approved);
        this.tv_rejected = (TextView) view.findViewById(R.id.tv_rejected);
        this.rl_allProducts = (RelativeLayout) view.findViewById(R.id.rl_allProducts);
        this.rl_products = (RelativeLayout) view.findViewById(R.id.rl_products);
        this.rl_pending = (RelativeLayout) view.findViewById(R.id.rl_pending);
        this.rl_approved = (RelativeLayout) view.findViewById(R.id.rl_approved);
        this.rl_rejected = (RelativeLayout) view.findViewById(R.id.rl_rejected);
        this.rl_allProducts.setOnClickListener(this);
        this.rl_products.setOnClickListener(this);
        this.rl_pending.setOnClickListener(this);
        this.rl_approved.setOnClickListener(this);
        this.rl_rejected.setOnClickListener(this);
    }

    void bindUI(ArrayList<ItemData> data) {
        this.arrayList = data;
        this.allProducts = data.size();
        for (int i = 0; i < data.size(); i++) {
            ItemData itemData = (ItemData) data.get(i);
            if (itemData.getProduct_status() == 2) {
                this.approvedProducts++;
            } else if (itemData.getProduct_status() == 3) {
                this.rejectedProducts++;
            } else if (itemData.getProduct_status() == 1) {
                this.pendingProducts++;
            }
        }
        this.tv_all_products.setText(String.valueOf(this.allProducts));
        this.tv_product.setText(String.valueOf(this.allProducts));
        this.tv_pending.setText(String.valueOf(this.pendingProducts));
        this.tv_approved.setText(String.valueOf(this.approvedProducts));
        this.tv_rejected.setText(String.valueOf(this.rejectedProducts));
        if (!GlobalMethods.commonDataRetrieved) {
            RetroCallForGetCommonData();
        }
    }

    public void RetroCallForGetVendorAllProductList(int userid) {
        try {
            if (GlobalMethods.isConnectedToInternet(getActivity(), false)) {
                GlobalMethods.ShowDialog(getActivity());
                api.get_vendor_all_product_list(userid).enqueue(new Callback<ArrayList<ItemData>>() {
                    public void onResponse(Call<ArrayList<ItemData>> call, Response<ArrayList<ItemData>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            if (((ArrayList) response.body()).size() > 0) {
                                VendorHomeFragment.this.bindUI((ArrayList) response.body());
                            } else {
                                Toast.makeText(VendorHomeFragment.this.getActivity(), "Product not available", Toast.LENGTH_SHORT).show();
                            }
                        }
                        GlobalMethods.hideDialog();
                    }

                    public void onFailure(Call<ArrayList<ItemData>> call, Throwable t) {
                        Toast.makeText(VendorHomeFragment.this.getActivity(), "There was an error", Toast.LENGTH_SHORT).show();
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
        }
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rl_allProducts:
                if(allProducts>0){
                    productListActivity(0);
                }
                return;
            case R.id.rl_approved:
                if(approvedProducts>0){
                    productListActivity(2);
                }
                return;
            case R.id.rl_products:
                if(allProducts>0){
                    productListActivity(0);
                }
                return;
            case R.id.rl_rejected:
                if(rejectedProducts>0){
                    productListActivity(3);
                }
                return;
            case R.id.rl_pending:
                if(pendingProducts>0){
                    productListActivity(1);
                }
                return;
            default:
                return;
        }
    }

    void productListActivity(int a) {
        Intent intent = new Intent(getActivity(), VendorProductsListActivity.class);
        intent.putExtra("type", a);
        startActivity(intent);
    }

    public static void RetroCallForGetCommonData() {
        try {
            if (GlobalMethods.isConnectedToInternet(context, false)) {
                GlobalMethods.ShowDialog(context);
                api.get_all_common_data().enqueue(new Callback<CommonData>() {
                    public void onResponse(Call<CommonData> call, Response<CommonData> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            GlobalMethods.commonDataRetrieved = true;
                            if (((CommonData) response.body()).getCities() != null && ((CommonData) response.body()).getCities().size() > 0) {
                                GlobalMethods.citiesList = ((CommonData) response.body()).getCities();
                            }
                            if (((CommonData) response.body()).getLocalities() != null && ((CommonData) response.body()).getLocalities().size() > 0) {
                                GlobalMethods.localitiesList = ((CommonData) response.body()).getLocalities();
                            }
                            if (((CommonData) response.body()).getCategories() != null && ((CommonData) response.body()).getCategories().size() > 0) {
                                GlobalMethods.categoriesList = ((CommonData) response.body()).getCategories();
                            }
                            if (((CommonData) response.body()).getSub_categories() != null && ((CommonData) response.body()).getSub_categories().size() > 0) {
                                GlobalMethods.subCategoriesList = ((CommonData) response.body()).getSub_categories();
                            }
                        }
                        GlobalMethods.hideDialog();
                    }

                    public void onFailure(Call<CommonData> call, Throwable t) {
                        Toast.makeText(VendorHomeFragment.context, "There was an error", Toast.LENGTH_SHORT).show();
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
        }
    }
}
