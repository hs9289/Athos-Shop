package com.athosshop.newathos.activities;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.models.GeneralOutput;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.UserSessionManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChangePasswordActivity extends AppCompatActivity {
    EditText old_password,new_password,verify_password;
    Button submit;
    Context context;
    UserSessionManager sessionManager;
    API api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initUI();

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(old_password.getText().toString().isEmpty()){
                    Toast.makeText(context,"Please enter your old password",Toast.LENGTH_SHORT).show();
                    old_password.requestFocus();
                }else if(new_password.getText().toString().isEmpty()){
                    Toast.makeText(context,"Please enter your new password",Toast.LENGTH_SHORT).show();
                    new_password.requestFocus();
                }else if(!new_password.getText().toString().equals(verify_password.getText().toString())){
                    Toast.makeText(context,"Please enter valid password",Toast.LENGTH_SHORT).show();
                    verify_password.requestFocus();
                }else{
                    RetroCallForChangePassword(old_password.getText().toString(),new_password.getText().toString());
                }
            }
        });
    }

    void initUI(){
        context=ChangePasswordActivity.this;
        sessionManager=new UserSessionManager(context);
        api=GlobalMethods.getAPI(context);
        old_password=findViewById(R.id.old_password);
        new_password=findViewById(R.id.new_password);
        verify_password=findViewById(R.id.verify_password);
        submit=findViewById(R.id.submit);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() != 16908332) {
            return super.onOptionsItemSelected(item);
        }
        onBackPressed();
        return true;
    }

    public void RetroCallForChangePassword(String oldpass, String newpass) {
        try {
            if (GlobalMethods.isConnectedToInternet(getApplicationContext(), false)) {
                GlobalMethods.ShowDialog(context);
                this.api.change_password(sessionManager.getUserId(),oldpass,newpass).enqueue(new Callback<GeneralOutput>() {
                    public void onResponse(Call<GeneralOutput> call, Response<GeneralOutput> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            if(response.body().isStatus()){
                                onBackPressed();
                            }
                        }
                        GlobalMethods.hideDialog();
                    }

                    public void onFailure(Call<GeneralOutput> call, Throwable t) {
                        Toast.makeText(context, "There was an error", Toast.LENGTH_SHORT).show();
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
        }
    }
}
