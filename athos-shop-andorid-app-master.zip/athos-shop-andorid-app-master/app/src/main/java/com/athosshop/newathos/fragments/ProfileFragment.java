package com.athosshop.newathos.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.models.GeneralOutput;
import com.athosshop.newathos.models.UserData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.UserSessionManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileFragment extends Fragment {
    EditText address;
    API api;
    EditText email;
    EditText fname;
    EditText lname;
    EditText mobile;
    UserSessionManager sessionManager;
    Button submit;


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI(view);
        RetroCallForGetUserProfile(this.sessionManager.getUserId());
        this.submit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ProfileFragment.this.RetroCallForUpdateProfile(new UserData(ProfileFragment.this.sessionManager.getUserId(), ProfileFragment.this.fname.getText().toString(), ProfileFragment.this.lname.getText().toString(), ProfileFragment.this.email.getText().toString(), ProfileFragment.this.mobile.getText().toString(), ProfileFragment.this.address.getText().toString()));
            }
        });

    }

    void initUI(View view) {
        this.sessionManager = new UserSessionManager(getActivity());
        this.api = GlobalMethods.getAPI(getActivity());
        this.fname = (EditText) view.findViewById(R.id.fname);
        this.lname = (EditText) view.findViewById(R.id.lname);
        this.email = (EditText) view.findViewById(R.id.email);
        this.mobile = (EditText) view.findViewById(R.id.mobile);
        this.address = (EditText) view.findViewById(R.id.address);
        this.submit = (Button) view.findViewById(R.id.submit);
    }

    void bindUI(UserData userData) {
        this.fname.setText(userData.getFirst_name());
        this.lname.setText(userData.getLast_name());
        this.email.setText(userData.getEmail());
        this.mobile.setText(userData.getMobile());
        this.address.setText(userData.getAddress());
        this.sessionManager.setUserAddress(userData.getAddress());
    }

    public void RetroCallForUpdateProfile(final UserData userData) {
        try {
            if (GlobalMethods.isConnectedToInternet(getActivity(), false)) {
                GlobalMethods.ShowDialog(getActivity());
                this.api.update_user_profile(userData).enqueue(new Callback<GeneralOutput>() {
                    public void onResponse(Call<GeneralOutput> call, Response<GeneralOutput> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            if(response.body().isStatus()){
                                sessionManager.setFirstName(userData.getFirst_name());
                                sessionManager.setLastName(userData.getLast_name());
                                sessionManager.setUserEmail(userData.getEmail());
                                sessionManager.setUserMobile(userData.getMobile());
                                sessionManager.setUserAddress(userData.getAddress());
                            }
                            Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        GlobalMethods.hideDialog();
                    }

                    public void onFailure(Call<GeneralOutput> call, Throwable t) {
                        Toast.makeText(ProfileFragment.this.getActivity(), "There was an error", Toast.LENGTH_SHORT).show();
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void RetroCallForGetUserProfile(int userid) {
        try {
            if (GlobalMethods.isConnectedToInternet(getActivity(), false)) {
                GlobalMethods.ShowDialog(getActivity());
                this.api.get_user_profile(userid).enqueue(new Callback<UserData>() {
                    public void onResponse(Call<UserData> call, Response<UserData> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            if (((UserData) response.body()).isStatus()) {
                                ProfileFragment.this.bindUI((UserData) response.body());
                            }
                            Context activity = ProfileFragment.this.getActivity();
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(" ");
                            stringBuilder.append(((UserData) response.body()).getMessage());
                            Toast.makeText(activity, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
                        }
                        GlobalMethods.hideDialog();
                    }

                    public void onFailure(Call<UserData> call, Throwable t) {
                        Toast.makeText(ProfileFragment.this.getActivity(), "There was an error", Toast.LENGTH_SHORT).show();
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
        }
    }
}
