package com.athosshop.newathos.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.activities.HomeActivity;
import com.athosshop.newathos.activities.LoginActivity;
import com.athosshop.newathos.ccavenue.WebViewActivity;
import com.athosshop.newathos.ccavenue.utility.AvenuesParams;
import com.athosshop.newathos.ccavenue.utility.Constants;
import com.athosshop.newathos.ccavenue.utility.ServiceUtility;
import com.athosshop.newathos.utils.UserSessionManager;

import static com.facebook.FacebookSdk.getApplicationContext;

public class SelectPaymentTypeDialog extends Dialog {
    Context context;
    UserSessionManager sessionManager;
    EditText et_pin;
    MyDialogListener listener;

    public SelectPaymentTypeDialog(@NonNull Context context) {
        super(context);
        this.context = context;
        this.sessionManager = new UserSessionManager(context);
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(R.layout.select_payment_type_dialog_layout);


        et_pin = findViewById(R.id.et_pin);

        findViewById(R.id.online).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                listener.userSelectedValue("2");
//                dismiss();
                payment();
            }

        });
        findViewById(R.id.cod).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                listener.userSelectedValue("1");
//                dismiss();
                logingg();


//                Intent  intent= new Intent(getContext(), LoginActivity.class);
//                getContext().startActivity(intent);
            }
        });
    }

    public void logingg() {
        System.out.println("Payment COD");
        if (this.sessionManager.IsUserLogin()) {
            System.out.println("this.sessionManager.IsUserLogin() ---"+ this.sessionManager.IsUserLogin());
            listener.userSelectedValue("1");
            dismiss();
//            Intent intent = new Intent(getContext(), HomeActivity.class);
//            getContext().startActivity(intent);
        } else {
            Intent intent = new Intent(getContext(), LoginActivity.class);
            getContext().startActivity(intent);
        }
    }

    public void payment() {
        try {
            System.out.println("Payment Online");
            if (this.sessionManager.IsUserLogin()) {
                System.out.println("this.sessionManager.IsUserLogin() ---"+ this.sessionManager.IsUserLogin());
                listener.userSelectedValue("2");
                dismiss();
//                String vAccessCode = ServiceUtility.chkNull(Constants.ACCESS_CODE).toString().trim();
//                String vMerchantId = ServiceUtility.chkNull(Constants.MERCHANT_ID).toString().trim();
//                String vCurrency = ServiceUtility.chkNull(Constants.CURRENCY).toString().trim();
//                String vAmount = ServiceUtility.chkNull(10).toString().trim();
//                if (!vAccessCode.equals("") && !vMerchantId.equals("") && !vCurrency.equals("") && !vAmount.equals("")) {
//                    Intent intent = new Intent(getApplicationContext(), WebViewActivity.class);
//                    intent.putExtra(AvenuesParams.ACCESS_CODE, ServiceUtility.chkNull(Constants.ACCESS_CODE).toString().trim());
//                    intent.putExtra(AvenuesParams.MERCHANT_ID, ServiceUtility.chkNull(Constants.MERCHANT_ID).toString().trim());
//                    intent.putExtra(AvenuesParams.ORDER_ID, ServiceUtility.chkNull(System.currentTimeMillis()).toString().trim());
//                    intent.putExtra(AvenuesParams.CURRENCY, ServiceUtility.chkNull(Constants.CURRENCY).toString().trim());
//                    intent.putExtra(AvenuesParams.AMOUNT, ServiceUtility.chkNull(10).toString().trim());
//
//                    intent.putExtra(AvenuesParams.REDIRECT_URL, ServiceUtility.chkNull(Constants.REDIRECT_URL).toString().trim());
//                    intent.putExtra(AvenuesParams.CANCEL_URL, ServiceUtility.chkNull(Constants.CANCEL_URL).toString().trim());
//                    intent.putExtra(AvenuesParams.RSA_KEY_URL, ServiceUtility.chkNull(Constants.RSA_KEY_URL).toString().trim());
//
//
//                    context.startActivity(intent);
//                } else {
//                    showToast("All parameters are mandatory.");
//                }
//            }
            }else {
                Intent intent = new Intent(getContext(), LoginActivity.class);
                getContext().startActivity(intent);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public MyDialogListener getListener() {
        return listener;
    }

    public void setListener(MyDialogListener listener) {
        this.listener = listener;
    }

    public void showToast(String msg) {
        Toast.makeText(getApplicationContext(), "Toast: " + msg, Toast.LENGTH_LONG).show();
    }

}

