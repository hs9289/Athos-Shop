package com.athosshop.newathos.fragments;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.activities.VendorOrderDetailsActivity;
import com.athosshop.newathos.adapters.VendorOrderListAdapter;
import com.athosshop.newathos.models.VendorOrdersData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.UserSessionManager;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class VendorOrdersFragment extends Fragment {


    API api;
    ArrayList<VendorOrdersData> arrayList = new ArrayList();
    Context context;
    ListView listView;
    UserSessionManager sessionManager;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_vendor_orders, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI(view);

        RetroCallForGetAllOrders(sessionManager.getUserId());

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final VendorOrdersData obj = arrayList.get(position);
                Intent intent=new Intent(getActivity(),VendorOrderDetailsActivity.class);
                intent.putExtra("VendorOrdersData", obj);
                startActivity(intent);
            }
        });
    }

    void initUI(View view) {
        this.context = getActivity();
        this.api = GlobalMethods.getAPI(this.context);
        this.sessionManager = new UserSessionManager(this.context);
        this.listView = (ListView) view.findViewById(R.id.listView);
    }

    void bindListUI(ArrayList<VendorOrdersData> data) {
        this.arrayList = data;
        this.listView.setAdapter(new VendorOrderListAdapter(this.context, R.layout.vendor_order_list_item, this.arrayList));
    }

    public void RetroCallForGetAllOrders(int userid) {
        try {
            if (GlobalMethods.isConnectedToInternet(this.context, false)) {
                GlobalMethods.ShowDialog(this.context);
                this.api.get_vendor_orders_list(userid).enqueue(new Callback<ArrayList<VendorOrdersData>>() {
                    public void onResponse(Call<ArrayList<VendorOrdersData>> call, Response<ArrayList<VendorOrdersData>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            if ((response.body()).size() > 0) {
                                VendorOrdersFragment.this.bindListUI(response.body());
                            } else {
                                Toast.makeText(VendorOrdersFragment.this.context, "Product not available", Toast.LENGTH_SHORT).show();
                            }
                        }
                        GlobalMethods.hideDialog();
                    }

                    public void onFailure(Call<ArrayList<VendorOrdersData>> call, Throwable t) {
                        Toast.makeText(VendorOrdersFragment.this.context, "There was an error", Toast.LENGTH_SHORT).show();
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
            GlobalMethods.hideDialog();
        }
    }



}
