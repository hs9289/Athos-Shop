package com.athosshop.newathos.dialogs;

public interface MyDialogListener {
    public void userSelectedValue(String value);
}
