package com.athosshop.newathos.ccavenue;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.athosshop.newathos.R;
import com.athosshop.newathos.activities.CheckoutActivity;
import com.athosshop.newathos.activities.HomeActivity;
import com.athosshop.newathos.ccavenue.utility.AvenuesParams;
import com.athosshop.newathos.ccavenue.utility.Constants;
import com.athosshop.newathos.ccavenue.utility.LoadingDialog;
import com.athosshop.newathos.ccavenue.utility.RSAUtility;
import com.athosshop.newathos.ccavenue.utility.ServiceUtility;
import com.athosshop.newathos.models.GeneralOutput;
import com.athosshop.newathos.models.PaymentDetails;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;

public class WebViewActivity extends AppCompatActivity {
    Intent mainIntent;
    String encVal;
    String vResponse;
    API api;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
        mainIntent = getIntent();
        api = GlobalMethods.getAPI(this);
        builder = new AlertDialog.Builder(this);
        get_RSA_key(mainIntent.getStringExtra(AvenuesParams.ACCESS_CODE), mainIntent.getStringExtra(AvenuesParams.ORDER_ID));
    }

    @SuppressLint("StaticFieldLeak")
    private class RenderView extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            LoadingDialog.showLoadingDialog(WebViewActivity.this, "Loading...");
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            try {

                if (!ServiceUtility.chkNull(vResponse).equals("")
                        && ServiceUtility.chkNull(vResponse).toString().indexOf("ERROR") == -1) {
                    StringBuffer vEncVal = new StringBuffer("");
                    System.out.println("Key ----- " + vResponse);
                    vEncVal.append(ServiceUtility.addToPostParams(AvenuesParams.AMOUNT, mainIntent.getStringExtra(AvenuesParams.AMOUNT)));
                    vEncVal.append(ServiceUtility.addToPostParams(AvenuesParams.CURRENCY, mainIntent.getStringExtra(AvenuesParams.CURRENCY)));
//                    if (encVal.equals("") || encVal == null)
                    encVal = RSAUtility.encrypt(vEncVal.substring(0, vEncVal.length() - 1), vResponse);  //encrypt amount and currency
//                    System.out.println("Key ---- " + encVal);
//                    System.out.println("Key ---- " + vEncVal.substring(0, vEncVal.length() - 1));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
            LoadingDialog.cancelLoading();

            @SuppressWarnings("unused")
            class MyJavaScriptInterface {
                @JavascriptInterface
                public void processHTML(String html) {
                    // process the html source code to get final status of transaction
                    savePaymentDetails(html);
//                    String status = null;
//                    System.out.println(html);
//                    if (html.indexOf("Failure") != -1) {
//                        status = "Transaction Declined!";
//                    } else if (html.indexOf("Success") != -1) {
//                        status = "Transaction Successful!";
//                    } else if (html.indexOf("Aborted") != -1) {
//                        status = "Transaction Cancelled!";
//                    } else {
//                        status = "Status Not Known!";
//                    }
//
//                    System.out.println("Status --- " + status);
//                    Toast.makeText(getApplicationContext(), status, Toast.LENGTH_SHORT).show();
//                    Intent intent = new Intent(getApplicationContext(), StatusActivity.class);
//                    intent.putExtra("transStatus", status);
//                    startActivity(intent);
                }
            }

            final WebView webview = (WebView) findViewById(R.id.webview);
            webview.getSettings().setJavaScriptEnabled(true);
            webview.addJavascriptInterface(new MyJavaScriptInterface(), "HTMLOUT");
            webview.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(webview, url);
                    LoadingDialog.cancelLoading();
//                    System.out.println("URL ---" + url);
                    if (url.indexOf("/ccavResponseHandler.php") != -1) {
                        webview.loadUrl("javascript:window.HTMLOUT.processHTML('<head>'+document.getElementsByTagName('html')[0].innerHTML+'</head><body></body>');");
                    }
                }

                @Override
                public void onPageStarted(WebView view, String url, Bitmap favicon) {
                    super.onPageStarted(view, url, favicon);
                    LoadingDialog.showLoadingDialog(WebViewActivity.this, "Loading...");
                }
            });


//            System.out.println("Billing Data ==== " + billingData);
//                String postData = AvenuesParams.ACCESS_CODE + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.ACCESS_CODE), "UTF-8") + "&" + AvenuesParams.MERCHANT_ID + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.MERCHANT_ID), "UTF-8") + "&" + AvenuesParams.ORDER_ID + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.ORDER_ID), "UTF-8") + "&" + AvenuesParams.REDIRECT_URL + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.REDIRECT_URL), "UTF-8") + "&" + AvenuesParams.CANCEL_URL + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.CANCEL_URL), "UTF-8") + "&" + AvenuesParams.ENC_VAL + "=" + URLEncoder.encode(encVal, "UTF-8") +  URLEncoder.encode(encVal, "UTF-8");;
            try {
                String postData = AvenuesParams.ACCESS_CODE + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.ACCESS_CODE), "UTF-8") + "&" + AvenuesParams.MERCHANT_ID + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.MERCHANT_ID), "UTF-8") + "&" + AvenuesParams.ORDER_ID + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.ORDER_ID), "UTF-8") + "&" + AvenuesParams.REDIRECT_URL + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.REDIRECT_URL), "UTF-8") + "&" + AvenuesParams.CANCEL_URL + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.CANCEL_URL), "UTF-8") + "&" + AvenuesParams.ENC_VAL + "=" + URLEncoder.encode(encVal, "UTF-8");
                System.out.println("Billing Data ==== " + postData);
                webview.postUrl(Constants.TRANS_URL, postData.getBytes());
            } catch (Exception e) {
                System.out.println("error --- " + e.getMessage());
                e.printStackTrace();
            }

        }
    }

    public void get_RSA_key(final String ac, final String od) {
        LoadingDialog.showLoadingDialog(WebViewActivity.this, "Loading...");
//        vResponse = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAp4iaFYjJIj/mL6Xjp6ZmmOH7Q1i9kFlf" +
//                "1Xviqn1St7dRFp1AJTEJ6QKnc7NUQdlLMsP4Ye3FKT+s55B14PEeecxp191bK3XhJzu5+dqzWSMK" +
//                "0v6WGJzUxURoS+CS2UzFqYuCrdMK1uFBelQZhkhImbPFuW5TrVzHZRzJKxrJuc7HzoK1u+FzB0a6" +
//                "vNradWNsiT0uypPo0leRRXA4Q39GxKNvbxTnVVDrPbZUycCfrNIDZO2zp1Kx8/2MAw6wdzDeuXQo" +
//                "a1hd9oj36gS8FEWMEYl4ta7g3TbuepdlJ4GQRm/2GYD5j5VLSV185KXYkXb1znw7K3c18WUfy/8f" +
//                "cBhDtwIDAQAB";
//        new RenderView().execute();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, mainIntent.getStringExtra(AvenuesParams.RSA_KEY_URL),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Toast.makeText(WebViewActivity.this,response,Toast.LENGTH_LONG).show();
                        LoadingDialog.cancelLoading();

                        if (response != null && !response.equals("")) {
                            vResponse = response;     ///save retrived rsa key
                            if (vResponse.contains("!ERROR!")) {
                                show_alert(vResponse);
                            } else {
                                new RenderView().execute();   // Calling async task to get display content
                            }
                        } else {
                            show_alert("No response");
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        LoadingDialog.cancelLoading();
                        System.out.println("Key ----- " + error.toString());
//                        Toast.makeText(WebViewActivity.this,error.toString(),Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(AvenuesParams.ACCESS_CODE, ac);
                params.put(AvenuesParams.ORDER_ID, od);
                return params;
            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void show_alert(String msg) {
        AlertDialog alertDialog = new AlertDialog.Builder(
                WebViewActivity.this).create();

        alertDialog.setTitle("Error!!!");
        if (msg.contains("\n"))
            msg = msg.replaceAll("\\\n", "");

        alertDialog.setMessage(msg);

        alertDialog.setButton(Dialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });


        alertDialog.show();
    }

    void savePaymentDetails(String html) {
        try {
            PaymentDetails paymentDetails = new PaymentDetails();
            String html1 = "<head><head></head><body><center><br>Thank you for shopping with us. Your credit card has been charged and your transaction is successful. We will be shipping your order to you soon.<br><br><table cellspacing=\"4\" cellpadding=\"4\"><tbody><tr><td>order_id</td><td>athos14</td></tr><tr><td>tracking_id</td><td>308004952219</td></tr><tr><td>bank_ref_no</td><td>1554406627162</td></tr><tr><td>order_status</td><td>Success</td></tr><tr><td>failure_message</td><td></td></tr><tr><td>payment_mode</td><td>Net Banking</td></tr><tr><td>card_name</td><td>AvenuesTest</td></tr><tr><td>status_code</td><td>null</td></tr><tr><td>status_message</td><td>Y</td></tr><tr><td>currency</td><td>INR</td></tr><tr><td>amount</td><td>25.00</td></tr><tr><td>billing_name</td><td>jknjkn</td></tr><tr><td>billing_address</td><td>jknkjnkj</td></tr><tr><td>billing_city</td><td>kjnkjnkjn</td></tr><tr><td>billing_state</td><td>jknknkj</td></tr><tr><td>billing_zip</td><td>123456</td></tr><tr><td>billing_country</td><td>India</td></tr><tr><td>billing_tel</td><td>1234567890</td></tr><tr><td>billing_email</td><td>test@test.com</td></tr><tr><td>delivery_name</td><td>jknjkn</td></tr><tr><td>delivery_address</td><td>jknkjnkj</td></tr><tr><td>delivery_city</td><td>kjnkjnkjn</td></tr><tr><td>delivery_state</td><td>jknknkj</td></tr><tr><td>delivery_zip</td><td>123456</td></tr><tr><td>delivery_country</td><td>India</td></tr><tr><td>delivery_tel</td><td>1234567890</td></tr><tr><td>merchant_param1</td><td></td></tr><tr><td>merchant_param2</td><td></td></tr><tr><td>merchant_param3</td><td></td></tr><tr><td>merchant_param4</td><td></td></tr><tr><td>merchant_param5</td><td></td></tr><tr><td>vault</td><td>N</td></tr><tr><td>offer_type</td><td>null</td></tr><tr><td>offer_code</td><td>null</td></tr><tr><td>discount_value</td><td>0.0</td></tr><tr><td>mer_amount</td><td>25.00</td></tr><tr><td>eci_value</td><td>null</td></tr><tr><td>retry</td><td>N</td></tr><tr><td>response_code</td><td>0</td></tr><tr><td>billing_notes</td><td>kjnkjn</td></tr><tr><td>trans_date</td><td>05/04/2019 01:07:13</td></tr><tr><td>bin_country</td><td></td></tr></tbody></table><br></center></body></head>";
//            Document doc = Jsoup.parse(html);
            Document doc = Jsoup.parse(html1);
            System.out.println(doc.toString());
            Element body = doc.body();
            Elements trElements = body.getElementsByTag("tr");
            for (Element elements : trElements) {
                Elements tdElements = elements.getElementsByTag("td");
                if (tdElements.size() > 1) {
                    switch (tdElements.get(0).text()) {
                        case "order_id":
                            paymentDetails.setOrder_id(tdElements.get(1).text());
                            break;
                        case "tracking_id":
                            paymentDetails.setTracking_id(tdElements.get(1).text());
                            break;
                        case "bank_ref_no":
                            paymentDetails.setBank_ref_no(tdElements.get(1).text());
                            break;
                        case "order_status":
                            paymentDetails.setOrder_status(tdElements.get(1).text());
                            break;
                        case "failure_message":
                            paymentDetails.setFailure_message(tdElements.get(1).text());
                            break;
                        case "payment_mode":
                            paymentDetails.setPayment_mode(tdElements.get(1).text());
                            break;
                        case "card_name":
                            paymentDetails.setCard_name(tdElements.get(1).text());
                            break;
                        case "status_code":
                            paymentDetails.setStatus_code(tdElements.get(1).text());
                            break;
                        case "status_message":
                            paymentDetails.setStatus_message(tdElements.get(1).text());
                            break;
                        case "currency":
                            paymentDetails.setCurrency(tdElements.get(1).text());
                            break;
                        case "amount":
                            paymentDetails.setAmount(tdElements.get(1).text());
                            break;
                        case "response_code":
                            paymentDetails.setResponse_code(tdElements.get(1).text());
                            break;
                        case "billing_notes":
                            paymentDetails.setBilling_notes(tdElements.get(1).text());
                            break;
                        case "trans_date":
                            paymentDetails.setTrans_date(tdElements.get(1).text());
                            break;
                        case "bin_country":
                            paymentDetails.setBin_country(tdElements.get(1).text());
                            break;
                        case "retry":
                            paymentDetails.setRetry(tdElements.get(1).text());
                            break;
                        default:
                            break;
                    }
                }
            }

            paymentDetails.setDb_order_id(CheckoutActivity.CurrentOrderId);
            if (paymentDetails.getOrder_status() != null && paymentDetails.getOrder_status().equals("Success")) {
                RetroCallForSavePaymentDetails(paymentDetails);
            } else {
                GlobalMethods.cartList.clear();
                Toast.makeText(getApplicationContext(), "Payment not successful, Order cancelled.", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), HomeActivity.class));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void RetroCallForSavePaymentDetails(PaymentDetails paymentDetails) {
        try {
            if (GlobalMethods.isConnectedToInternet(getApplicationContext(), false)) {
                GlobalMethods.ShowDialog(this);
                this.api.save_payment_details(paymentDetails).enqueue(new Callback<GeneralOutput>() {
                    @Override
                    public void onResponse(Call<GeneralOutput> call, retrofit2.Response<GeneralOutput> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            if ((response.body()).isStatus()) {
                                GlobalMethods.cartList.clear();
//                                Toast.makeText(getApplicationContext(), "Payment done", Toast.LENGTH_SHORT).show();
//                                builder.setMessage(R.string.dialog_message).setTitle(R.string.dialog_title);
                                builder.setMessage("Your order has been placed successfully.")
                                        .setIcon(R.drawable.ic_cart_red).setCancelable(false)
                                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                                                finish();
                                            }
                                        });
                                //Creating dialog box
                                AlertDialog alert = builder.create();
                                //Setting the title manually
                                alert.setTitle("Order");
                                alert.show();
//                                startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                            } else {
                                Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }

                        }
                        GlobalMethods.hideDialog();
                    }

                    @Override
                    public void onFailure(Call<GeneralOutput> call, Throwable t) {
                        Toast.makeText(getApplicationContext(), "There was an error", Toast.LENGTH_SHORT).show();
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
