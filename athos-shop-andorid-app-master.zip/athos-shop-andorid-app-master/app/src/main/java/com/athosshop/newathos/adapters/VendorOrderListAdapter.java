package com.athosshop.newathos.adapters;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.athosshop.newathos.R;
import com.athosshop.newathos.models.VendorOrdersData;
import com.athosshop.newathos.utils.UserSessionManager;

import java.util.ArrayList;

public class VendorOrderListAdapter extends ArrayAdapter<VendorOrdersData> {
    ArrayList<VendorOrdersData> data;
    int layoutResourceId;
    Context mContext;
    UserSessionManager sessionManager;

    public VendorOrderListAdapter(Context mContext, int layoutResourceId, ArrayList<VendorOrdersData> data) {
        super(mContext, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.mContext = mContext;
        this.data = data;
        this.sessionManager=new UserSessionManager(mContext);
    }

    @NonNull
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            try {
                convertView = ((Activity) this.mContext).getLayoutInflater().inflate(this.layoutResourceId, parent, false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        VendorOrdersData objectItem = this.data.get(position);
        TextView tv_orderid = (TextView) convertView.findViewById(R.id.tv_orderid);
        TextView tv_itemname = convertView.findViewById(R.id.tv_itemname);
        TextView tv_itemqtn = convertView.findViewById(R.id.tv_itemqtn);
        TextView tv_totalamount = (TextView) convertView.findViewById(R.id.tv_totalamount);
        TextView tv_status = (TextView) convertView.findViewById(R.id.tv_status);
        TextView tv_order_datetime = convertView.findViewById(R.id.tv_order_datetime);
        TextView tv_orderPin = convertView.findViewById(R.id.tv_orderPin);

        tv_orderid.setText("#"+String.valueOf(objectItem.getOrder_id()));
        tv_itemname.setText(objectItem.getProduct_name());
        tv_itemqtn.setText(String.valueOf(objectItem.getQuantity()));

        tv_totalamount.setText((objectItem.getPrice()*objectItem.getQuantity())+"/-");
        tv_order_datetime.setText(objectItem.getCreated_at());
        tv_orderPin.setText(objectItem.getOrder_pin());

        if (objectItem.getItem_status() == 0) {
            tv_status.setText("NA");
            tv_status.setTextColor(this.mContext.getResources().getColor(R.color.small_text_color));
        }else if (objectItem.getItem_status() == 1) {
            tv_status.setText("Pending");
            tv_status.setTextColor(this.mContext.getResources().getColor(R.color.blue));
        } else if (objectItem.getItem_status() == 2) {
            tv_status.setText("Delivered");
            tv_status.setTextColor(this.mContext.getResources().getColor(R.color.green));
        } else if (objectItem.getItem_status() == 3) {
            tv_status.setText("Cancelled");
            tv_status.setTextColor(this.mContext.getResources().getColor(R.color.red));
        }


        return convertView;
    }
}
