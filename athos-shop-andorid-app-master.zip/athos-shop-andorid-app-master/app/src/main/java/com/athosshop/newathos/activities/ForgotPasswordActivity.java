package com.athosshop.newathos.activities;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.models.GeneralOutput;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgotPasswordActivity extends AppCompatActivity {
    API api;
    EditText et_email;

    /* renamed from: com.romilandroid.athos.activities.ForgotPasswordActivity$1 */
    class C07291 implements OnClickListener {
        C07291() {
        }

        public void onClick(View v) {
            if (ForgotPasswordActivity.this.et_email.getText().toString().isEmpty()) {
                Toast.makeText(ForgotPasswordActivity.this.getApplicationContext(), "Please Enter valid Email", Toast.LENGTH_SHORT).show();
                return;
            }
            ForgotPasswordActivity forgotPasswordActivity = ForgotPasswordActivity.this;
            forgotPasswordActivity.RetroCallForSendNewPassword(forgotPasswordActivity.et_email.getText().toString());
        }
    }

    /* renamed from: com.romilandroid.athos.activities.ForgotPasswordActivity$2 */
    class C07302 implements Callback<GeneralOutput> {
        C07302() {
        }

        public void onResponse(Call<GeneralOutput> call, Response<GeneralOutput> response) {
            if (response.isSuccessful() && response.body() != null) {
                ((GeneralOutput) response.body()).isStatus();
                Context applicationContext = ForgotPasswordActivity.this.getApplicationContext();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(" ");
                stringBuilder.append(((GeneralOutput) response.body()).getMessage());
                Toast.makeText(applicationContext, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
            }
            GlobalMethods.hideDialog();
        }

        public void onFailure(Call<GeneralOutput> call, Throwable t) {
            Toast.makeText(ForgotPasswordActivity.this.getApplicationContext(), "There was an error", Toast.LENGTH_SHORT).show();
            GlobalMethods.hideDialog();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.api = GlobalMethods.getAPI(this);
        this.et_email = (EditText) findViewById(R.id.et_email);
        findViewById(R.id.btn_send).setOnClickListener(new C07291());
    }

    public void RetroCallForSendNewPassword(String email) {
        try {
            if (GlobalMethods.isConnectedToInternet(getApplicationContext(), false)) {
                GlobalMethods.ShowDialog(this);
                this.api.send_password(email).enqueue(new C07302());
            }
        } catch (Exception e) {
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() != 16908332) {
            return super.onOptionsItemSelected(item);
        }
        onBackPressed();
        return true;
    }
}
