package com.athosshop.newathos.utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.athosshop.newathos.R;
import com.athosshop.newathos.models.Category;
import com.athosshop.newathos.models.City;
import com.athosshop.newathos.models.ItemData;
import com.athosshop.newathos.models.Locality;
import com.athosshop.newathos.models.SubCategory;
import com.athosshop.newathos.network.API;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit.Builder;
import retrofit2.converter.gson.GsonConverterFactory;

public class GlobalMethods {
    //    public static String BaseUrl = "https://www.athosshop.com/api/athos_api/food_supply/";
    public static String BaseUrl = "https://www.athosshop.com/api/athos_api/food_supply/food_api.php/";
    public static String BaseUrlPic = "https://www.athosshop.com/api/athos_api/food_supply/";
    public static String BaseUrl1 = "http://192.168.42.81/food_supply/";
    public static String BaseUrl2 = "http://dreemworksolutions.com/athos_api/food_supply/";
    public static ArrayList<ItemData> cartList = new ArrayList();
    public static ArrayList<Category> categoriesList = new ArrayList();
    public static ArrayList<City> citiesList = new ArrayList();
    public static boolean commonDataRetrieved = false;
    public static ArrayList<Locality> localitiesList = new ArrayList();
    static ProgressDialog pd;
    public static ArrayList<SubCategory> subCategoriesList = new ArrayList();

    /* renamed from: com.romilandroid.athos.utils.GlobalMethods$1 */
    static class C08001 implements OnClickListener {
        C08001() {
        }

        public void onClick(DialogInterface dialog, int which) {
            dialog.cancel();
        }
    }

    public static API getAPI(Context context) {
        String uriAddress = context.getResources().getString(R.string.api_url);
        Gson gson = new GsonBuilder().setLenient().create();
        return (API) new Builder().baseUrl(uriAddress).addConverterFactory(GsonConverterFactory.create(gson)).client(new OkHttpClient().newBuilder().readTimeout(20, TimeUnit.SECONDS).connectTimeout(20, TimeUnit.SECONDS).build()).build().create(API.class);
//    getUnsafeOkHttpClient()
    }

    public static boolean isConnectedToInternet(Context _context, boolean ShowConnectionDialog) {
        Boolean isInternetPresent = Boolean.valueOf(false);
        if (_context != null) {
            ConnectivityManager connectivity = (ConnectivityManager) _context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivity != null) {
                NetworkInfo info = connectivity.getActiveNetworkInfo();
                if (info != null) {
                    if (info.getState() == State.CONNECTED) {
                        isInternetPresent = Boolean.valueOf(true);
                    }
                }
            }
        }
        if (_context != null && (_context instanceof Activity) && !isInternetPresent.booleanValue() && ShowConnectionDialog) {
            ShowAlertDialog(_context, "No Internet Connection", "You don't have internet connection.", Boolean.valueOf(false));
        }
        return isInternetPresent.booleanValue();
    }

    public static void ShowAlertDialog(Context _context, String title, String message, Boolean status) {
        if (_context != null && (_context instanceof Activity)) {
            AlertDialog alertDialog = new AlertDialog.Builder(_context).create();
            alertDialog.setTitle(title);
            alertDialog.setMessage(message);
            alertDialog.setButton("OK", new C08001());
            if (!((Activity) _context).isFinishing()) {
                alertDialog.show();
            }
        }
    }

    public static void ShowDialog(Context context) {
        pd = new ProgressDialog(context);
        pd.setMessage(context.getString(R.string.wait_a_moment));
        pd.setCancelable(false);
        pd.show();
    }

    public static void hideDialog() {
        pd.dismiss();
    }

    public static int getCategoryIdByName(String category) {
        int cid = 0;
        try {
            if (categoriesList.size() > 0) {
                for (int i = 0; i < categoriesList.size(); i++) {
                    Category category1 = (Category) categoriesList.get(i);
                    if (category1.getCategory_name().equals(category)) {
                        cid = category1.getId();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cid;
    }

    public static int getSubCategoryIdByName(String category) {
        int cid = 0;
        try {
            if (subCategoriesList.size() > 0) {
                for (int i = 0; i < subCategoriesList.size(); i++) {
                    SubCategory category1 = (SubCategory) subCategoriesList.get(i);
                    if (category1.getCategory().equals(category)) {
                        cid = category1.getId();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cid;
    }

    public static int getCityIdByName(String city) {
        int cid = 0;
        try {
            if (citiesList.size() > 0) {
                for (int i = 0; i < citiesList.size(); i++) {
                    City city1 = (City) citiesList.get(i);
                    if (city1.getLocation_name().equals(city)) {
                        cid = city1.getId();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cid;
    }

    public static int getLocalityIdByName(String locality) {
        int lid = 0;
        try {
            if (localitiesList.size() > 0) {
                for (int i = 0; i < localitiesList.size(); i++) {
                    Locality locality1 = (Locality) localitiesList.get(i);
                    if (locality1.getLocality_name().equals(locality)) {
                        lid = locality1.getId();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lid;
    }

    public static String getCityNameById(int cid) {
        String city = "";
        try {
            if (citiesList.size() > 0) {
                for (int i = 0; i < citiesList.size(); i++) {
                    City city1 = (City) citiesList.get(i);
                    if (city1.getId() == cid) {
                        city = city1.getLocation_name();
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return city;
    }

    public static String getLocalityNameById(int lid) {
        String locality = "";
        try {
            if (localitiesList.size() > 0) {
                for (int i = 0; i < localitiesList.size(); i++) {
                    Locality locality1 = (Locality) localitiesList.get(i);
                    if (locality1.getId() == lid) {
                        locality = locality1.getLocality_name();
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return locality;
    }

    public static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) {
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());

            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0]);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });

            OkHttpClient okHttpClient = builder.build();
            return okHttpClient;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
