package com.athosshop.newathos.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.models.CommonData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SplashScreenActivity extends Activity {
    API api;
    Thread splashTread;

    /* renamed from: com.romilandroid.athos.activities.SplashScreenActivity$1 */
    class C07511 extends Thread {
        C07511() {
        }

        public void run() {
            int waited = 0;
            while (!GlobalMethods.commonDataRetrieved && waited < 3000) {
                try {
                    C07511.sleep(100);
                    waited += 100;
                } catch (InterruptedException e) {
                } catch (Throwable th) {
                    SplashScreenActivity.this.finish();
                }
            }
            Intent intent = new Intent(SplashScreenActivity.this, HomeActivity.class);
//            Intent intent = new Intent(SplashScreenActivity.this, SelectUserTypeActivity.class);
//            intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            SplashScreenActivity.this.startActivity(intent);
//            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            SplashScreenActivity.this.finish();
//            SplashScreenActivity.this.finish();
        }
    }

    /* renamed from: com.romilandroid.athos.activities.SplashScreenActivity$2 */
    class C07522 implements Callback<CommonData> {
        C07522() {
        }

        public void onResponse(Call<CommonData> call, Response<CommonData> response) {
            System.out.println("DATA -----" + response.body());
            if (response.isSuccessful() && response.body() != null) {
                GlobalMethods.commonDataRetrieved = true;
                if (((CommonData) response.body()).getCities() != null && ((CommonData) response.body()).getCities().size() > 0) {
                    GlobalMethods.citiesList = ((CommonData) response.body()).getCities();
                }
                if (((CommonData) response.body()).getLocalities() != null && ((CommonData) response.body()).getLocalities().size() > 0) {
                    GlobalMethods.localitiesList = ((CommonData) response.body()).getLocalities();
                }
                if (((CommonData) response.body()).getCategories() != null && ((CommonData) response.body()).getCategories().size() > 0) {
                    GlobalMethods.categoriesList = ((CommonData) response.body()).getCategories();
                }
                if (((CommonData) response.body()).getSub_categories() != null && ((CommonData) response.body()).getSub_categories().size() > 0) {
                    GlobalMethods.subCategoriesList = ((CommonData) response.body()).getSub_categories();
                }
            }
        }

        public void onFailure(Call<CommonData> call, Throwable t) {
            System.out.println("Splash DATA -----" + t.getLocalizedMessage());
            Toast.makeText(SplashScreenActivity.this.getApplicationContext(), "There was an error" + t.toString(), Toast.LENGTH_LONG).show();
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        getWindow().setFormat(1);
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_splash_screen);
        this.api = GlobalMethods.getAPI(this);
        RetroCallForGetCommonData();
        startSplash();
    }

    private void startSplash() {
        this.splashTread = new C07511();
        this.splashTread.start();
    }

    public void RetroCallForGetCommonData() {
        try {
            if (GlobalMethods.isConnectedToInternet(getApplicationContext(), false)) {
                this.api.get_all_common_data().enqueue(new C07522());
            }
        } catch (Exception e) {
            System.out.println("S Exception DATA -----");
            e.printStackTrace();
        }
    }
}
