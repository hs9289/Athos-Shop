package com.athosshop.newathos.models;

public class OrdersData {
    private String cart;
    private String created_at;
    private int id;
    private int number_of_products;
    private int order_status;
    private String payment_id;
    private double total_amount;
    private String updated_at;
    private int user_id;
    private int item_status;
    private int order_details_id;
    private String order_pin;
    private int order_type;

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUser_id() {
        return this.user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public double getTotal_amount() {
        return this.total_amount;
    }

    public void setTotal_amount(double total_amount) {
        this.total_amount = total_amount;
    }

    public int getNumber_of_products() {
        return this.number_of_products;
    }

    public void setNumber_of_products(int number_of_products) {
        this.number_of_products = number_of_products;
    }

    public int getOrder_status() {
        return this.order_status;
    }

    public void setOrder_status(int order_status) {
        this.order_status = order_status;
    }

    public String getCart() {
        return this.cart;
    }

    public void setCart(String cart) {
        this.cart = cart;
    }

    public String getPayment_id() {
        return this.payment_id;
    }

    public void setPayment_id(String payment_id) {
        this.payment_id = payment_id;
    }

    public String getCreated_at() {
        return this.created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return this.updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    public int getItem_status() {
        return item_status;
    }

    public void setItem_status(int item_status) {
        this.item_status = item_status;
    }

    public int getOrder_details_id() {
        return order_details_id;
    }

    public void setOrder_details_id(int order_details_id) {
        this.order_details_id = order_details_id;
    }

    public String getOrder_pin() {
        return order_pin;
    }

    public void setOrder_pin(String order_pin) {
        this.order_pin = order_pin;
    }

    public int getOrder_type() {
        return order_type;
    }

    public void setOrder_type(int order_type) {
        this.order_type = order_type;
    }
}
