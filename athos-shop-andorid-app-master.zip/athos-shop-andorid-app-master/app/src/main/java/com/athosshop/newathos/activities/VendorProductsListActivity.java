package com.athosshop.newathos.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.adapters.VendorItemListAdapter;
import com.athosshop.newathos.models.ItemData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.UserSessionManager;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VendorProductsListActivity extends AppCompatActivity {
    public static ArrayList<ItemData> arrayList = new ArrayList();
    public static VendorItemListAdapter productAdapter;
    API api;
    ListView listView;
    UserSessionManager sessionManager;
    int type = 0;

    /* renamed from: com.romilandroid.athos.activities.VendorProductsListActivity$1 */
    class C07531 implements Callback<ArrayList<ItemData>> {
        C07531() {
        }

        public void onResponse(Call<ArrayList<ItemData>> call, Response<ArrayList<ItemData>> response) {
            if (response.isSuccessful() && response.body() != null) {
                if (((ArrayList) response.body()).size() > 0) {
                    VendorProductsListActivity.this.bindUI((ArrayList) response.body());
                } else {
                    Toast.makeText(VendorProductsListActivity.this.getApplicationContext(), "Product not available", Toast.LENGTH_SHORT).show();
                }
            }
            GlobalMethods.hideDialog();
        }

        public void onFailure(Call<ArrayList<ItemData>> call, Throwable t) {
            Toast.makeText(VendorProductsListActivity.this.getApplicationContext(), "There was an error", Toast.LENGTH_SHORT).show();
            GlobalMethods.hideDialog();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_products_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initUI();
        if (getIntent().getExtras() != null) {
            this.type = getIntent().getExtras().getInt("type");
        }
        RetroCallForGetVendorAllProductList(this.sessionManager.getUserId());
    }

    void initUI() {
        this.listView = (ListView) findViewById(R.id.listView);
        this.api = GlobalMethods.getAPI(this);
        this.sessionManager = new UserSessionManager(this);
        arrayList.clear();
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() != 16908332) {
            return super.onOptionsItemSelected(item);
        }
        onBackPressed();
        return true;
    }

    void bindUI(ArrayList<ItemData> data) {
        //arrayList = data;
        if(type!=0){
            for (int i = 0; i < data.size(); i++) {
                ItemData itemData = data.get(i);
                if (itemData.getProduct_status() == type) {
                    arrayList.add(itemData);
                }
            }
        }else{
            arrayList = data;
        }

        productAdapter = new VendorItemListAdapter(this, R.layout.vendor_item_list_item, arrayList);
        this.listView.setAdapter(productAdapter);
    }

    public void RetroCallForGetVendorAllProductList(int userid) {
        try {
            if (GlobalMethods.isConnectedToInternet(getApplicationContext(), false)) {
                GlobalMethods.ShowDialog(this);
                this.api.get_vendor_all_product_list(userid).enqueue(new C07531());
            }
        } catch (Exception e) {
        }
    }
}
