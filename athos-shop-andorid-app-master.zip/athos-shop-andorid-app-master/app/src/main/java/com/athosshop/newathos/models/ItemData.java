package com.athosshop.newathos.models;

import java.io.Serializable;

public class ItemData implements Serializable {
    private int category;
    private String description;
    private int image;
    private int order_status;
    private float price;
    private int product_id;
    private String product_image;
    private String product_name;
    private int product_status;
    private int quantity;
    private int remaining_quantity;
    private int sold;
    private int sub_category;
    private int supplier_id;

    public ItemData(){

    }

    public ItemData(String product_name, String description, float price, int image, int order_status) {
        this.product_name = product_name;
        this.description = description;
        this.price = price;
        this.image = image;
        this.order_status = order_status;
    }

    public ItemData(int supplier_id, String product_name, int category, int sub_category, String description, float price) {
        this.product_name = product_name;
        this.supplier_id = supplier_id;
        this.category = category;
        this.sub_category = sub_category;
        this.description = description;
        this.price = price;
        this.product_image = this.product_image;
        this.order_status = this.order_status;
    }

    public int getProduct_id() {
        return this.product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public int getSupplier_id() {
        return this.supplier_id;
    }

    public void setSupplier_id(int supplier_id) {
        this.supplier_id = supplier_id;
    }

    public int getCategory() {
        return this.category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public int getSub_category() {
        return this.sub_category;
    }

    public void setSub_category(int sub_category) {
        this.sub_category = sub_category;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getPrice() {
        return this.price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getProduct_image() {
        return this.product_image;
    }

    public void setProduct_image(String product_image) {
        this.product_image = product_image;
    }

    public int getOrder_status() {
        return this.order_status;
    }

    public void setOrder_status(int order_status) {
        this.order_status = order_status;
    }

    public String getProduct_name() {
        return this.product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public int getImage() {
        return this.image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getSold() {
        return this.sold;
    }

    public void setSold(int sold) {
        this.sold = sold;
    }

    public int getQuantity() {
        return this.quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getProduct_status() {
        return this.product_status;
    }

    public void setProduct_status(int product_status) {
        this.product_status = product_status;
    }

    public int getRemaining_quantity() {
        return this.remaining_quantity;
    }

    public void setRemaining_quantity(int remaining_quantity) {
        this.remaining_quantity = remaining_quantity;
    }
}
