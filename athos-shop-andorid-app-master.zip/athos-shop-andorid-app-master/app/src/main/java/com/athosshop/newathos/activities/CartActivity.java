package com.athosshop.newathos.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.adapters.CartItemListAdapter;
import com.athosshop.newathos.models.ItemData;
import com.athosshop.newathos.utils.GlobalMethods;

public class CartActivity extends AppCompatActivity {
    public static CartItemListAdapter adapter;
    public static double totalAmount = 0.0d;
    public static TextView tv_totalAmount;
    ListView listView;
    RelativeLayout rl_checkout,rl_add_more;

    /* renamed from: com.romilandroid.athos.activities.CartActivity$1 */
    class C07241 implements OnClickListener {
        C07241() {
        }

        public void onClick(View v) {
            if (GlobalMethods.cartList.size() > 0) {
                CartActivity cartActivity = CartActivity.this;
                cartActivity.startActivity(new Intent(cartActivity.getApplicationContext(), CheckoutActivity.class));
                return;
            }
            Toast.makeText(CartActivity.this.getApplicationContext(), "Please add an item in cart.", Toast.LENGTH_SHORT).show();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initUI();
        bindList();
        this.rl_checkout.setOnClickListener(new C07241());

        rl_add_more.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() != 16908332) {
            return super.onOptionsItemSelected(item);
        }
        onBackPressed();
        return true;
    }

    void initUI() {
        this.listView = (ListView) findViewById(R.id.listView);
        this.rl_checkout = (RelativeLayout) findViewById(R.id.rl_checkout);
        rl_add_more=findViewById(R.id.rl_add_more);
        tv_totalAmount = (TextView) findViewById(R.id.tv_totalAmount);
    }

    void bindList() {
        adapter = new CartItemListAdapter(this, R.layout.cart_item_list_item, GlobalMethods.cartList);
        this.listView.setAdapter(adapter);
        justifyListViewHeightBasedOnChildren(this.listView);
        calculatePrice();
    }

    public static void calculatePrice() {
        totalAmount = 0.0d;
        for (int i = 0; i < GlobalMethods.cartList.size(); i++) {
            ItemData itemData = (ItemData) GlobalMethods.cartList.get(i);
            totalAmount += (double) (itemData.getPrice() * ((float) itemData.getQuantity()));
        }
        tv_totalAmount.setText(String.valueOf(totalAmount));
    }

    public static void justifyListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter adapter = listView.getAdapter();
        if (adapter != null) {
            ViewGroup vg = listView;
            int totalHeight = 0;
            for (int i = 0; i < adapter.getCount(); i++) {
                View listItem = adapter.getView(i, null, vg);
                listItem.measure(0, 0);
                totalHeight += listItem.getMeasuredHeight();
            }
            LayoutParams par = listView.getLayoutParams();
            par.height = (listView.getDividerHeight() * (adapter.getCount() - 1)) + totalHeight;
            listView.setLayoutParams(par);
            listView.requestLayout();
        }
    }
}
