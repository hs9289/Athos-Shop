package com.athosshop.newathos.network;

import com.athosshop.newathos.models.Category;
import com.athosshop.newathos.models.City;
import com.athosshop.newathos.models.CommonData;
import com.athosshop.newathos.models.GeneralOutput;
import com.athosshop.newathos.models.ItemData;
import com.athosshop.newathos.models.Locality;
import com.athosshop.newathos.models.OrderDetails;
import com.athosshop.newathos.models.OrdersData;
import com.athosshop.newathos.models.PaymentDetails;
import com.athosshop.newathos.models.SubCategory;
import com.athosshop.newathos.models.UserData;
import com.athosshop.newathos.models.VendorData;
import com.athosshop.newathos.models.VendorOrdersData;

import java.util.ArrayList;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface API {
    @POST("add_new_item")
    @Multipart
    Call<GeneralOutput> add_new_item(@Part MultipartBody.Part part,
                                     @Part("supplier_id") RequestBody supplier_id,
                                     @Part("product_name") RequestBody product_name,
                                     @Part("category") RequestBody category,
                                     @Part("sub_category") RequestBody sub_category,
                                     @Part("description") RequestBody description,
                                     @Part("price") RequestBody price);

    @GET("create_order")
    Call<GeneralOutput> create_order(@Query("order_data") String str,
                                     @Query("userid") int i,
                                     @Query("total_amount") double d,
                                     @Query("address") String str2,
                                     @Query("datetime") String str3,
                                     @Query("order_city") int order_city,
                                     @Query("order_pin") String order_pin,
                                     @Query("payment_type") String paymentType,
                                     @Query("city") int city,
                                     @Query("locality") int locality);

    @GET("delete_product")
    Call<GeneralOutput> delete_product(@Query("productid") int i);

    @GET("get_all_common_data")
    Call<CommonData> get_all_common_data();

    @GET("get_all_product_list")
    Call<ArrayList<ItemData>> get_all_product_list(@Query("category") int i);

    @GET("get_categories_list")
    Call<ArrayList<Category>> get_categories_list();

    @GET("get_city_list")
    Call<ArrayList<City>> get_city_list();

    @GET("get_localities_list")
    Call<ArrayList<Locality>> get_localities_list();

    @GET("get_orders_list")
    Call<ArrayList<OrdersData>> get_orders_list(@Query("userid") int i);

    @GET("get_vendor_orders_list")
    Call<ArrayList<VendorOrdersData>> get_vendor_orders_list(@Query("userid") int i);

    @GET("get_subcategories_list")
    Call<ArrayList<SubCategory>> get_subcategories_list();

    @GET("get_user_profile")
    Call<UserData> get_user_profile(@Query("userid") int i);

    @GET("get_vendor_all_product_list")
    Call<ArrayList<ItemData>> get_vendor_all_product_list(@Query("userid") int i);

    @GET("get_vendor_profile")
    Call<VendorData> get_vendor_profile(@Query("userid") int i);

    @GET("login_user")
    Call<UserData> login_user(@Query("username") String str, @Query("password") String str2, @Query("lat") double d, @Query("lon") double d2);

    @GET("register_user")
    Call<UserData> register_user(@Query("fname") String str, @Query("lname") String str2, @Query("email") String str3,  @Query("mobile")String mobile,@Query("password") String str4, @Query("usertype") int i, @Query("lat") double d, @Query("lon") double d2);

    @GET("send_password")
    Call<GeneralOutput> send_password(@Query("email") String str);

    @POST("update_user_profile")
    Call<GeneralOutput> update_user_profile(@Body UserData userData);

    @POST("update_vendor_profile")
    Call<GeneralOutput> update_vendor_profile(@Body VendorData vendorData);

    @POST("upload_vendor_idcard_picture")
    @Multipart
    Call<GeneralOutput> upload_vendor_idcard_picture(@Part MultipartBody.Part part,
                                                     @Part("type") RequestBody type,
                                                     @Part("userid") RequestBody userid);

    @POST("upload_vendor_video")
    @Multipart
    Call<GeneralOutput> upload_vendor_video(@Part MultipartBody.Part part,
                                            @Part("userid") RequestBody userid);

    @POST("save_payment_details")
    Call<GeneralOutput> save_payment_details(@Body PaymentDetails paymentDetails);

    @GET("get_order_details")
    Call<OrderDetails> get_order_details(@Query("orderid") int orderid);

    @GET("update_order_item_status")
    Call<GeneralOutput> update_order_item_status(@Query("order_details_id") int order_details_id);

    @POST("update_item_details")
    Call<GeneralOutput> update_item_details(@Body ItemData itemData);

    @GET("change_password")
    Call<GeneralOutput> change_password(@Query("userid") int userid,
                                        @Query("old_password") String oldpass,
                                        @Query("new_password") String newpass);
}
