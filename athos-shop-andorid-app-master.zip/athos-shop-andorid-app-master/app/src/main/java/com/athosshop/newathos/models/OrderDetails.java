package com.athosshop.newathos.models;

import java.util.ArrayList;

public class OrderDetails {
    private boolean status;
    private OrdersData OrderData;
    private ArrayList<ProductData> OrderItems;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public OrdersData getOrderData() {
        return OrderData;
    }

    public void setOrderData(OrdersData orderData) {
        OrderData = orderData;
    }

    public ArrayList<ProductData> getOrderItems() {
        return OrderItems;
    }

    public void setOrderItems(ArrayList<ProductData> orderItems) {
        OrderItems = orderItems;
    }

    public class ProductData{
        private String product_id;
        private String quantity;
        private String supplier_id;
        private String type;
        private String product_name;
        private String price;
        private String product_image;
        private String category;
        private String description;
        private String first_name;
        private String last_name;

        public String getProduct_id() {
            return product_id;
        }

        public void setProduct_id(String product_id) {
            this.product_id = product_id;
        }

        public String getQuantity() {
            return quantity;
        }

        public void setQuantity(String quantity) {
            this.quantity = quantity;
        }

        public String getSupplier_id() {
            return supplier_id;
        }

        public void setSupplier_id(String supplier_id) {
            this.supplier_id = supplier_id;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getProduct_name() {
            return product_name;
        }

        public void setProduct_name(String product_name) {
            this.product_name = product_name;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getProduct_image() {
            return product_image;
        }

        public void setProduct_image(String product_image) {
            this.product_image = product_image;
        }

        public String getCategory() {
            return category;
        }

        public void setCategory(String category) {
            this.category = category;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getFirst_name() {
            return first_name;
        }

        public void setFirst_name(String first_name) {
            this.first_name = first_name;
        }

        public String getLast_name() {
            return last_name;
        }

        public void setLast_name(String last_name) {
            this.last_name = last_name;
        }
    }
}
