package com.athosshop.newathos.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class UserSessionManager {
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context context;


    public static final String FirebaseToken = "token";
    private static final String FirstName = "firstname";
    private static final String IS_USER_LOGIN = "IsUserLoggedIn";
    private static final String LastName = "lastname";
    public static final String PREFER_NAME = "com.romilandroid.foodsupplier";
    public static int PRIVATE_MODE = 0;
    public static final String SignInToken = "signintoken";
    private static final String UserAadhaar = "aadhaar";
    private static final String UserAddress = "address";
    private static final String UserCity = "usercity";
    private static final String UserEmail = "useremail";
    public static final String UserId = "userid";
    private static final String UserLat = "userlat";
    private static final String UserLocality = "userlocality";
    private static final String UserLon = "userlon";
    private static final String UserMobile = "usermobile";
    private static final String UserProfilePic = "userprofilepic";
    private static final String UserSocialId = "socialid";
    private static final String UserType = "usertype";

    public UserSessionManager(Context context) {
        this.context = context;
        pref = context.getSharedPreferences(PREFER_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void setFirebaseToken(String token) {
        this.editor.putString(FirebaseToken, token);
        this.editor.commit();
    }

    public String getFirebaseToken() {
        return this.pref.getString(FirebaseToken, null);
    }

    public int getUserId() {
        return this.pref.getInt(UserId, 0);
    }

    public void setUserId(int userid) {
        this.editor.putInt(UserId, userid);
        this.editor.commit();
    }

    public String getSignInToken() {
        return this.pref.getString(SignInToken, null);
    }

    public void setSignInToken(String signintoken) {
        this.editor.putString(SignInToken, signintoken);
        this.editor.commit();
    }

    public boolean IsUserLogin() {
        return this.pref.getBoolean(IS_USER_LOGIN, false);
    }

    public void setUserLogin(Boolean bool) {
        this.editor.putBoolean(IS_USER_LOGIN, bool.booleanValue());
        this.editor.commit();
    }

    public void setFirstName(String firstName) {
        this.editor.putString(FirstName, firstName);
        this.editor.commit();
    }

    public String getFirstName() {
        return this.pref.getString(FirstName, null);
    }

    public void setLastName(String lastName) {
        this.editor.putString(LastName, lastName);
        this.editor.commit();
    }

    public String getLastName() {
        return this.pref.getString(LastName, null);
    }

    public void setUserEmail(String email) {
        this.editor.putString(UserEmail, email);
        this.editor.commit();
    }

    public String getUserEmail() {
        return this.pref.getString(UserEmail, null);
    }

    public void setUserMobile(String mobile) {
        this.editor.putString(UserMobile, mobile);
        this.editor.commit();
    }

    public String getUserMobile() {
        return this.pref.getString(UserMobile, null);
    }

    public void setUserLon(String lon) {
        this.editor.putString(UserLon, lon);
        this.editor.commit();
    }

    public String getUserLon() {
        return this.pref.getString(UserLon, null);
    }

    public void setUserLat(String lat) {
        this.editor.putString(UserLat, lat);
        this.editor.commit();
    }

    public String getUserLat() {
        return this.pref.getString(UserLat, null);
    }

    public void setUserProfilePic(String pic) {
        this.editor.putString(UserProfilePic, pic);
        this.editor.commit();
    }

    public String getUserProfilePic() {
        return this.pref.getString(UserProfilePic, null);
    }

    public void setUserSocialId(String id) {
        this.editor.putString(UserSocialId, id);
        this.editor.commit();
    }

    public String getUserSocialId() {
        return this.pref.getString(UserSocialId, null);
    }

    public void setUserAadhaar(String aadhaar) {
        this.editor.putString(UserAadhaar, aadhaar);
        this.editor.commit();
    }

    public String getUserAadhaar() {
        return this.pref.getString(UserAadhaar, null);
    }

    public void setUserAddress(String address) {
        this.editor.putString(UserAddress, address);
        this.editor.commit();
    }

    public int getUserType() {
        return this.pref.getInt(UserType, 0);
    }

    public void setUserType(int usertype) {
        this.editor.putInt(UserType, usertype);
        this.editor.commit();
    }

    public String getUserAddress() {
        return this.pref.getString(UserAddress, null);
    }

    public int getUserCity() {
        return this.pref.getInt(UserCity, 0);
    }

    public void setUserCity(int userCity) {
        this.editor.putInt(UserCity, userCity);
        this.editor.commit();
    }

    public int getUserLocality() {
        return this.pref.getInt(UserLocality, 0);
    }

    public void setUserLocality(int userLocality) {
        this.editor.putInt(UserLocality, userLocality);
        this.editor.commit();
    }

    public void clearSession() {
        this.editor.clear();
        this.editor.commit();
    }
}
