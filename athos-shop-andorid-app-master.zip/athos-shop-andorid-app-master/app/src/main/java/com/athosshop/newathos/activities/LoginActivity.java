package com.athosshop.newathos.activities;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.models.UserData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.MyLocationTracker;
import com.athosshop.newathos.utils.UserSessionManager;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    int PERMISSION_REQUEST = 22;
    API api;
    int backButtonCount = 0;
    double lat;
    double lon;
    EditText password;
    UserSessionManager sessionManager;
    EditText username;

    /* renamed from: com.romilandroid.athos.activities.LoginActivity$1 */
    class C07321 implements OnClickListener {
        C07321() {
        }

        public void onClick(View v) {
            if (LoginActivity.this.validate()) {
                LoginActivity loginActivity = LoginActivity.this;
                loginActivity.RetroCallForLogin(loginActivity.username.getText().toString(), LoginActivity.this.password.getText().toString());
            }
        }
    }

    /* renamed from: com.romilandroid.athos.activities.LoginActivity$2 */
    class C07332 implements OnClickListener {
        C07332() {
        }

        public void onClick(View v) {
            LoginActivity loginActivity = LoginActivity.this;
            loginActivity.startActivity(new Intent(loginActivity.getApplicationContext(), SignupActivity.class));
        }
    }

    /* renamed from: com.romilandroid.athos.activities.LoginActivity$3 */
    class C07343 implements OnClickListener {
        C07343() {
        }

        public void onClick(View v) {
            Context context = LoginActivity.this;
            context.startActivity(new Intent(context, ForgotPasswordActivity.class));
        }
    }

    /* renamed from: com.romilandroid.athos.activities.LoginActivity$4 */
    class C07354 implements Callback<UserData> {
        C07354() {
        }

        public void onResponse(Call<UserData> call, Response<UserData> response) {
            if (response.isSuccessful() && response.body() != null) {
                Context context;
                System.out.println("----"+((UserData) response.body()).isStatus());
                if (((UserData) response.body()).isStatus()) {
                    LoginActivity.this.sessionManager.setSignInToken(((UserData) response.body()).getToken());
                    LoginActivity.this.sessionManager.setUserId(((UserData) response.body()).getId());
                    LoginActivity.this.sessionManager.setUserType(((UserData) response.body()).getUser_type());
                    LoginActivity.this.sessionManager.setUserLogin(Boolean.valueOf(true));
                    LoginActivity.this.sessionManager.setUserEmail(((UserData) response.body()).getEmail());
                    LoginActivity.this.sessionManager.setUserMobile(((UserData) response.body()).getMobile());
                    LoginActivity.this.sessionManager.setFirebaseToken(((UserData) response.body()).getFirebase_token());
                    if (((UserData) response.body()).getUser_type() == 1) {
                        context = LoginActivity.this;
                        context.startActivity(new Intent(context, HomeActivity.class));
                    } else if (((UserData) response.body()).getUser_type() == 2) {
                        context = LoginActivity.this;
                        context.startActivity(new Intent(context, VendorHomeActivity.class));
                    }
                }
                context = LoginActivity.this.getApplicationContext();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(" ");
                stringBuilder.append(((UserData) response.body()).getMessage());
                Toast.makeText(context, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
            }
            GlobalMethods.hideDialog();
        }

        public void onFailure(Call<UserData> call, Throwable t) {
            Toast.makeText(LoginActivity.this.getApplicationContext(), "There was an error", Toast.LENGTH_SHORT).show();
            GlobalMethods.hideDialog();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        initUI();
        if (isLocationPermissionAllowed()) {
            getLocation();
        } else {
            requestLocationPermission();
        }
        if (this.sessionManager.IsUserLogin()){
            if (this.sessionManager.getUserType() == 1) {
               startActivity(new Intent(getApplicationContext(), HomeActivity.class));
            } else {
                startActivity(new Intent(getApplicationContext(), VendorHomeActivity.class));
            }
        }
        findViewById(R.id.login).setOnClickListener(new C07321());
        findViewById(R.id.signup_text).setOnClickListener(new C07332());
        findViewById(R.id.forgot_password_text).setOnClickListener(new C07343());
    }

    public void onBackPressed() {
        if (this.backButtonCount >= 1) {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return;
        }
        Toast.makeText(this, "Press Back button again", Toast.LENGTH_SHORT).show();
        this.backButtonCount++;
    }

    void initUI() {
        this.api = GlobalMethods.getAPI(this);
        this.sessionManager = new UserSessionManager(this);
        this.username = (EditText) findViewById(R.id.username);
        this.password = (EditText) findViewById(R.id.password);
    }

    boolean validate() {
        boolean status = true;
        try {
            if (this.username.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Please Enter username", Toast.LENGTH_SHORT).show();
                status = false;
                this.username.requestFocus();
            }
            if (this.password.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Please Enter password", Toast.LENGTH_SHORT).show();
                status = false;
                this.password.requestFocus();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    public void RetroCallForLogin(String username, String password) {
        try {
            if (GlobalMethods.isConnectedToInternet(getApplicationContext(), false)) {
                GlobalMethods.ShowDialog(this);
                this.api.login_user(username, password, this.lat, this.lon).enqueue(new C07354());
            }
        } catch (Exception e) {
        }
    }

    void getLocation() {
        MyLocationTracker myLocationTracker = new MyLocationTracker(getApplicationContext());
        this.lat = myLocationTracker.getLatitude();
        this.lon = myLocationTracker.getLongitude();
        if (this.lat == 0.0d) {
            Location l = myLocationTracker.getLastKnownLocation();
            if (l != null) {
                this.lat = l.getLatitude();
                this.lon = l.getLongitude();
            }
        }
        Log.d("Lat:- ", String.valueOf(this.lat));
        Log.d("Lon:- ", String.valueOf(this.lon));
    }

    private boolean isLocationPermissionAllowed() {
        try {
            int location1 = ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION");
            int location2 = ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION");
            List<String> listPermissionNeeded = new ArrayList();
            if (location1 != 0) {
                listPermissionNeeded.add("android.permission.ACCESS_COARSE_LOCATION");
            }
            if (location2 != 0) {
                listPermissionNeeded.add("android.permission.ACCESS_FINE_LOCATION");
            }
            if (listPermissionNeeded.isEmpty()) {
                return true;
            }
            ActivityCompat.requestPermissions(this, (String[]) listPermissionNeeded.toArray(new String[listPermissionNeeded.size()]), this.PERMISSION_REQUEST);
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private void requestLocationPermission() {
        try {
            ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.ACCESS_COARSE_LOCATION");
            ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.ACCESS_FINE_LOCATION");
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"}, this.PERMISSION_REQUEST);
        } catch (Exception e) {
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == this.PERMISSION_REQUEST) {
            getLocation();
        }
    }
}
