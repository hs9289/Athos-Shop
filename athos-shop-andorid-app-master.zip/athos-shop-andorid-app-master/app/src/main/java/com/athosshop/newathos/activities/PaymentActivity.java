package com.athosshop.newathos.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.ccavenue.WebViewActivity;
import com.athosshop.newathos.ccavenue.utility.AvenuesParams;
import com.athosshop.newathos.ccavenue.utility.ServiceUtility;

public class PaymentActivity extends AppCompatActivity {
    String accessCode="AVHU82GA81AW82UHWA";
    String merchantId="204607";
    String currency="INR";
    String amount="1.00";
    String orderId="2776273";
//    String redirectUrl="http://122.182.6.216/merchant/ccavResponseHandler.jsp";
//    String cancelUrl="http://122.182.6.216/merchant/ccavResponseHandler.jsp";
//    String rsaKeyUrl="https://secure.ccavenue.com/transaction/jsp/GetRSA.jsp";

//    String redirectUrl="http://192.168.43.178/athos/ccavenue/ccavResponseHandler.jsp";
//    String cancelUrl="http://192.168.43.178/athos/ccavenue/ccavResponseHandler.jsp";
//    String rsaKeyUrl="http://192.168.43.178/athos/ccavenue/GetRSA.php";

    String redirectUrl="https://www.athosshop.com/ccavenue/ccavResponseHandler.php";
    String cancelUrl="https://www.athosshop.com/ccavenue/ccavResponseHandler.php";
    String rsaKeyUrl="https://www.athosshop.com/ccavenue/GetRSA.php";

    //http://api.athosshop.com/athos_api/food_supply/ccavenue



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        initPayment();
    }

    @Override
    protected void onStart() {
        super.onStart();
        //generating new order number for every transaction
        Integer randomNum = ServiceUtility.randInt(0, 9999999);
        orderId=randomNum.toString();
    }

    void initPayment(){
        String vAccessCode = ServiceUtility.chkNull(accessCode).toString().trim();
        String vMerchantId = ServiceUtility.chkNull(merchantId).toString().trim();
        String vCurrency = ServiceUtility.chkNull(currency).toString().trim();
        String vAmount = ServiceUtility.chkNull(amount).toString().trim();
        if(!vAccessCode.equals("") && !vMerchantId.equals("") && !vCurrency.equals("") && !vAmount.equals("")){
            Intent intent = new Intent(this, WebViewActivity.class);
            intent.putExtra(AvenuesParams.ACCESS_CODE, ServiceUtility.chkNull(accessCode).toString().trim());
            intent.putExtra(AvenuesParams.MERCHANT_ID, ServiceUtility.chkNull(merchantId).toString().trim());
            intent.putExtra(AvenuesParams.ORDER_ID, ServiceUtility.chkNull(orderId).toString().trim());
            intent.putExtra(AvenuesParams.CURRENCY, ServiceUtility.chkNull(currency).toString().trim());
            intent.putExtra(AvenuesParams.AMOUNT, ServiceUtility.chkNull(amount).toString().trim());

            intent.putExtra(AvenuesParams.REDIRECT_URL, ServiceUtility.chkNull(redirectUrl).toString().trim());
            intent.putExtra(AvenuesParams.CANCEL_URL, ServiceUtility.chkNull(cancelUrl).toString().trim());
            intent.putExtra(AvenuesParams.RSA_KEY_URL, ServiceUtility.chkNull(rsaKeyUrl).toString().trim());


            startActivity(intent);
        }else{
            Toast.makeText(getApplicationContext(),"All parameters are mandatory.",Toast.LENGTH_SHORT).show();
        }
    }
}
