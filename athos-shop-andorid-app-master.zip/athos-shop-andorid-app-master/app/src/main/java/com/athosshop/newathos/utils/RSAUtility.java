package com.athosshop.newathos.utils;

import android.util.Base64;
import com.bumptech.glide.load.Key;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;

public class RSAUtility {
    public static String encrypt(String plainText, String key) {
        try {
            PublicKey publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.decode(key, 0)));
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(1, publicKey);
            return Base64.encodeToString(cipher.doFinal(plainText.getBytes(Key.STRING_CHARSET_NAME)), 0);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
