package com.athosshop.newathos.activities;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.athosshop.newathos.R;
import com.athosshop.newathos.adapters.DateListAdapter;
import com.athosshop.newathos.ccavenue.WebViewActivity;
import com.athosshop.newathos.ccavenue.utility.AvenuesParams;
import com.athosshop.newathos.ccavenue.utility.Constants;
import com.athosshop.newathos.ccavenue.utility.ServiceUtility;
import com.athosshop.newathos.dialogs.MyDialogListener;
import com.athosshop.newathos.dialogs.SelectPaymentTypeDialog;
import com.athosshop.newathos.models.GeneralOutput;
import com.athosshop.newathos.models.ItemData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.UserSessionManager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CheckoutActivity extends AppCompatActivity implements OnDateSetListener, OnTimeSetListener {
    API api;
    Context context;
    String date = "";
    ArrayList<String> dateList = new ArrayList();
    String datetime = "";

    EditText et_address;
    ListView listView_date;
    ListView listView_time;
    RelativeLayout rl_payment;
    UserSessionManager sessionManager;
    String time = "";
    ArrayList<String> timeList = new ArrayList();
    TextView tv_datetime;
    TextView tv_totalAmount;
    int cityId = 0;
    String orderPin = "";
    AlertDialog.Builder builder;
    public static String CurrentOrderId = "";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initUI();
        bindDateList();
        bindTimeList();


//        CheckoutActivity.this.sessionManager.setUserLogin(Boolean.valueOf(true));
        this.et_address.setText(this.sessionManager.getUserAddress());
        this.tv_totalAmount.setText(String.valueOf(CartActivity.totalAmount));

        this.rl_payment.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) {
                    sessionManager.setUserAddress(et_address.getText().toString());
                    SelectPaymentTypeDialog dialog = new SelectPaymentTypeDialog(CheckoutActivity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    dialog.show();
                    dialog.setListener(new MyDialogListener() {
                        @Override
                        public void userSelectedValue(String value) {
                            if (value != null && !value.equals("")) {
                                RetroCallForUploadOrder(String.valueOf(getOrderArray()),
                                        sessionManager.getUserId(),
                                        CartActivity.totalAmount,
                                        et_address.getText().toString(),
                                        tv_datetime.getText().toString(), cityId, getOrderPin(),
                                        value);
                            }
                        }
                    });
                }
                //startActivity(new Intent(getApplicationContext(),PaymentActivity.class));
                //CheckoutActivity checkoutActivity = CheckoutActivity.this;
                //checkoutActivity.startActivity(new Intent(checkoutActivity.getApplicationContext(), PaymentActivity.class));
            }
        });

        this.listView_date.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CheckoutActivity checkoutActivity = CheckoutActivity.this;
                checkoutActivity.date = checkoutActivity.dateList.get(position);
                tv_datetime.setText(date + "/" + time);
            }
        });

        this.listView_time.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CheckoutActivity checkoutActivity = CheckoutActivity.this;
                checkoutActivity.time = (String) checkoutActivity.timeList.get(position);
                tv_datetime.setText(date + "/" + time);
            }
        });
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() != 16908332) {
            return super.onOptionsItemSelected(item);
        }
        onBackPressed();
        return true;
    }

    boolean validate() {
        boolean status = true;
        if (this.et_address.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please Enter Delivery Address", Toast.LENGTH_SHORT).show();
            status = false;
        }
        if (this.date.equals("")) {
            Toast.makeText(getApplicationContext(), "Please Select Date", Toast.LENGTH_SHORT).show();
            status = false;
        }
        if (!this.time.equals("")) {
            return status;
        }
        Toast.makeText(getApplicationContext(), "Please Select Time", Toast.LENGTH_SHORT).show();
        return false;
    }

    void initUI() {
        this.context = this;
        this.api = GlobalMethods.getAPI(this);
        this.sessionManager = new UserSessionManager(this);
        this.rl_payment = (RelativeLayout) findViewById(R.id.rl_payment);
        this.et_address = (EditText) findViewById(R.id.et_address);
        this.tv_totalAmount = (TextView) findViewById(R.id.tv_totalAmount);
        this.listView_date = (ListView) findViewById(R.id.listView_date);
        this.listView_time = (ListView) findViewById(R.id.listView_time);
        this.tv_datetime = (TextView) findViewById(R.id.tv_datetime);
        builder = new AlertDialog.Builder(this);
    }

    void bindDateList() {
        this.listView_date.setAdapter(new DateListAdapter(this, R.layout.date_list_item_layout, getDateList()));
    }

    void bindTimeList() {
        this.listView_time.setAdapter(new DateListAdapter(this, R.layout.date_list_item_layout, getTimeList()));
    }

    ArrayList<String> getDateList() {
        this.dateList.clear();
        Date dt = new Date();

        Calendar c = Calendar.getInstance();
        c.setTime(dt);

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        this.dateList.add(formatter.format(c.getTime()));

        for (int i = 0; i < 3; i++) {

            //  c.add(Calendar.DAY_OF_YEAR, 0+i);
            c.add(Calendar.DAY_OF_MONTH, 1);
            //    System.out.println("Current index is: " + i);
            // 23 ke jagh 22  ana chaye
            this.dateList.add(formatter.format(c.getTime()));
        }
        return this.dateList;
    }

    ArrayList<String> getTimeList() {
        this.timeList.clear();
        for (int i = 0; i < 4; i++) {
            if (i == 0) {
                this.timeList.add("9 AM to 12 noon");
            } else if (i == 1) {
                this.timeList.add("12 noon to 3 PM");
            } else if (i == 2) {
                this.timeList.add("3 PM to 6 PM");
            } else if (i == 3) {
                this.timeList.add("6 PM to 9 PM");
            }
        }
        return this.timeList;
    }

    JsonArray getOrderArray() {
        JsonArray orderArray = new JsonArray();
        if (GlobalMethods.cartList.size() > 0) {
            for (int i = 0; i < GlobalMethods.cartList.size(); i++) {
                ItemData obj = (ItemData) GlobalMethods.cartList.get(i);
                JSONObject orderdata = new JSONObject();
                try {
                    orderdata.put("product_id", obj.getProduct_id());
                    orderdata.put("supplier_id", obj.getSupplier_id());
                    orderdata.put("quantity", obj.getQuantity());
                    orderdata.put("price", obj.getPrice());
                    orderArray.add(String.valueOf(orderdata));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
        return orderArray;
    }

    String getOrderPin() {
        int pin = new Random().nextInt((9999 - 1111) + 1) + 1111;
        return String.valueOf(pin);
    }

    public void RetroCallForUploadOrder(String orderdata, int userid, final double total_amount, final String address, String datetime, int cityId, String orderPin, final String paymentType) {
        try {
            if (GlobalMethods.isConnectedToInternet(getApplicationContext(), false)) {
                GlobalMethods.ShowDialog(this);
                this.api.create_order(orderdata, userid, total_amount, address, datetime, cityId,
                        orderPin, paymentType, sessionManager.getUserCity(), sessionManager.getUserLocality()).enqueue(new Callback<GeneralOutput>() {
                    @Override
                    public void onResponse(Call<GeneralOutput> call, Response<GeneralOutput> response) {
                        GlobalMethods.hideDialog();
                        if (response.isSuccessful() && response.body() != null) {
                            if ((response.body()).isStatus()) {
                                GlobalMethods.cartList.clear();

                                if (paymentType.endsWith("2")) {
                                    //CurrentOrderId=response.body().getMessage().substring(5);
                                    billingDetails(address);
                                    CurrentOrderId = response.body().getMessage();
                                    initPayment(String.valueOf(total_amount), response.body().getMessage());
                                } else {
//                                    builder.setMessage(R.string.dialog_message).setTitle(R.string.dialog_title);
                                    builder.setMessage("Order has been placed.")
                                            .setIcon(R.drawable.ic_cart_red).setCancelable(false)
                                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                                                    finish();
                                                }
                                            });
                                    //Creating dialog box
                                    AlertDialog alert = builder.create();
                                    //Setting the title manually
                                    alert.setTitle("Order");
                                    alert.show();

//                                    Toast.makeText(getApplicationContext(), "Your order has been created successfully ", Toast.LENGTH_SHORT).show();


                                }
                            } else {
                                Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<GeneralOutput> call, Throwable t) {
                        Toast.makeText(CheckoutActivity.this.getApplicationContext(), "There was an error", Toast.LENGTH_SHORT).show();
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void openDatePicker() {
        try {
            Calendar now = Calendar.getInstance();
            new DatePickerDialog(this, this, now.get(1), now.get(2), now.get(5)).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void openTimePicker() {
        try {
            Calendar now = Calendar.getInstance();
            new TimePickerDialog(this, this, now.get(11), now.get(12), false).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        try {
            String date = year + "-" + (month + 1) + "-" + dayOfMonth;
            this.datetime = date;
            openTimePicker();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        String time = hourOfDay + ":" + minute + ":00";
        this.datetime = time;
    }

    void billingDetails(String billingAddress) {
        String billingCity = GlobalMethods.getCityNameById(sessionManager.getUserCity());
        Constants.BILLING_ADDRESS = billingAddress;
        Constants.BILLING_CITY = billingCity;
        Constants.BILLING_STATE = "U.P.";
        Constants.BILLING_COUNTRY = "India";
        Constants.BILLING_EMAIL = sessionManager.getUserEmail();
        Constants.BILLING_TEL = sessionManager.getUserMobile();
        Constants.DELIVERY_ADDRESS = billingAddress;
        Constants.DELIVERY_CITY = billingCity;
        Constants.DELIVERY_STATE = "U.P.";
        Constants.DELIVERY_COUNTRY = "India";
        Constants.DELIVERY_TEL = sessionManager.getUserMobile();
    }

    void initPayment(String amount, String orderId) {
        String vAccessCode = ServiceUtility.chkNull(Constants.ACCESS_CODE).toString().trim();
        String vMerchantId = ServiceUtility.chkNull(Constants.MERCHANT_ID).toString().trim();
        String vCurrency = ServiceUtility.chkNull(Constants.CURRENCY).toString().trim();
        String vAmount = ServiceUtility.chkNull(amount).toString().trim();
        if (!vAccessCode.equals("") && !vMerchantId.equals("") && !vCurrency.equals("") && !vAmount.equals("")) {
            Intent intent = new Intent(this, WebViewActivity.class);
            intent.putExtra(AvenuesParams.ACCESS_CODE, ServiceUtility.chkNull(Constants.ACCESS_CODE).toString().trim());
            intent.putExtra(AvenuesParams.MERCHANT_ID, ServiceUtility.chkNull(Constants.MERCHANT_ID).toString().trim());
            intent.putExtra(AvenuesParams.ORDER_ID, ServiceUtility.chkNull(orderId).toString().trim());
            intent.putExtra(AvenuesParams.CURRENCY, ServiceUtility.chkNull(Constants.CURRENCY).toString().trim());
            intent.putExtra(AvenuesParams.AMOUNT, ServiceUtility.chkNull(amount).toString().trim());
            intent.putExtra(AvenuesParams.REDIRECT_URL, ServiceUtility.chkNull(Constants.REDIRECT_URL).toString().trim());
            intent.putExtra(AvenuesParams.CANCEL_URL, ServiceUtility.chkNull(Constants.CANCEL_URL).toString().trim());
            intent.putExtra(AvenuesParams.RSA_KEY_URL, ServiceUtility.chkNull(Constants.RSA_KEY_URL).toString().trim());


            startActivity(intent);
        } else {
            Toast.makeText(getApplicationContext(), "All parameters are mandatory.", Toast.LENGTH_SHORT).show();
        }
    }

}


//        public void facbookpixel()
//        {
//
//            Bundle parameters = new Bundle();
//// IF YOU CHOOSE NOT TO USE A RECOMMENDED PARAM, THEN REMOVE IT, DON'T LEAVE IT EMPTY
//
//// REQUIRED: DO NOT change this, must be set to 'vehicle'
//            parameters.putString(AppEventsConstants.EVENT_PARAM_CONTENT_TYPE, "vehicle");
//
//// REQUIRED: content id of the vehicle that is shown
//            parameters.putString(AppEventsConstants.EVENT_PARAM_CONTENT_ID, "123");
//
//// RECOMMENDED: postal_code
//            parameters.putString("fb_postal_code", "94025");
//
//// RECOMMENDED: country
//            parameters.putString("fb_country", "United States");
//
//// RECOMMENDED: make
//// Allows you to target people based on their search of a specific make
//            parameters.putString("fb_make", "Lexus");
//
//// RECOMMENDED: model
//// Allows you to target people based on their search of a specific make model
//            parameters.putString("fb_model", "ES");
//
//// RECOMMENDED: year, in yyyy format
//// Allows you to target people based on their search for vehicles manufactured from a specific year
//            parameters.putInt("fb_year", "2017");
//
//// RECOMMENDED: state_of_vehicle
//// Allows you to target people based on their search of specific type of vehicle
//            parameters.putString("fb_state_of_vehicle", "CPO");
//
//// RECOMMENDED: exterior_color
//            parameters.putString("fb_exterior_color", "black");
//
//// RECOMMENDED: transmission
//            parameters.putString("fb_transmission", "automatic");
//
//// RECOMMENDED: body_style
//// Allows you to target people based on their search of a vehicle body style
//            parameters.putString("fb_body_style", "sedan");
//
//// RECOMMENDED: fuel_type
//            parameters.putString("fb_fuel_type", "gasoline");
//
//// RECOMMENDED: drivetrain
//            parameters.putString("fb_drivetrain", "awd");
//
//// RECOMMENDED: price
//            parameters.putInt("fb_price", (int) 1234.99);
//
//// RECOMMENDED: currency
//            parameters.putInt("fb_currency", Integer.parseInt("USD"));
//
//// RECOMMENDED: preferred_price_range
//            parameters.putInt("fb_preferred_price_range", Integer.parseInt("[10000,20000]"));
//
//// Fire the 'ViewContent' event on the vehicle details or other specific content page
//            logger.logEvent(AppEventsConstants.EVENT_NAME_VIEWED_CONTENT,
//                    parameters
//
//            );
//        }
//
//}
