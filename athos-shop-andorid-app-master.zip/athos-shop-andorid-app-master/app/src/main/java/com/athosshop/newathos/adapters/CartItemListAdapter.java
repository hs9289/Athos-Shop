package com.athosshop.newathos.adapters;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.athosshop.newathos.R;
import com.athosshop.newathos.activities.CartActivity;
import com.athosshop.newathos.models.ItemData;
import com.athosshop.newathos.utils.GlobalMethods;
import java.util.ArrayList;

public class CartItemListAdapter extends ArrayAdapter<ItemData> {
    ArrayList<ItemData> data;
    int layoutResourceId;
    Context mContext;

    public CartItemListAdapter(Context mContext, int layoutResourceId, ArrayList<ItemData> data) {
        super(mContext, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.mContext = mContext;
        this.data = data;
    }

    @NonNull
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            try {
                convertView = ((Activity) this.mContext).getLayoutInflater().inflate(this.layoutResourceId, parent, false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        final ItemData objectItem = (ItemData) this.data.get(position);

        ImageView iv_item_image = (ImageView) convertView.findViewById(R.id.iv_item_image);
        TextView tv_itemamount = (TextView) convertView.findViewById(R.id.tv_itemamount);
        ImageView iv_minus = (ImageView) convertView.findViewById(R.id.iv_minus);
        ImageView iv_plus = (ImageView) convertView.findViewById(R.id.iv_plus);
        final TextView tv_qtn = (TextView) convertView.findViewById(R.id.tv_qtn);
        ImageButton btn_remove = (ImageButton) convertView.findViewById(R.id.btn_remove);
        TextView tv_qtn_unit=convertView.findViewById(R.id.tv_qtn_unit);
        ((TextView) convertView.findViewById(R.id.tv_itemname)).setText(objectItem.getProduct_name());

        if(objectItem.getCategory()==2){
            tv_itemamount.setText("Rs. "+objectItem.getPrice()+"/Kg");
            tv_qtn_unit.setText("Kg");
        }else{
            tv_itemamount.setText("Rs. "+objectItem.getPrice()+"/Kg");
            tv_qtn_unit.setText("Kg");
        }

        tv_qtn.setText(String.valueOf(objectItem.getQuantity()));
        if (objectItem.getProduct_image() != null) {
            RequestManager with = Glide.with(this.mContext);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(GlobalMethods.BaseUrlPic);
            stringBuilder2.append(objectItem.getProduct_image());
            with.load(stringBuilder2.toString()).placeholder(R.drawable.demo).dontAnimate().into(iv_item_image);
        }
        iv_plus.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if(objectItem.getCategory()==5){
                    objectItem.setQuantity(objectItem.getQuantity() + 5);
                }else{
                    objectItem.setQuantity(objectItem.getQuantity() + 1);
                }
                tv_qtn.setText(String.valueOf(objectItem.getQuantity()));
                CartActivity.calculatePrice();
            }
        });
        iv_minus.setOnClickListener(new OnClickListener() {

            /* renamed from: com.romilandroid.athos.adapters.CartItemListAdapter$2$1 */
            class C07601 implements DialogInterface.OnClickListener {
                C07601() {
                }

                public void onClick(DialogInterface dialog, int whichButton) {
                    for (int i = 0; i < GlobalMethods.cartList.size(); i++) {
                        if (((ItemData) GlobalMethods.cartList.get(i)).getProduct_id() == objectItem.getProduct_id()) {
                            GlobalMethods.cartList.remove(i);
                        }
                    }
                    CartActivity.adapter.notifyDataSetChanged();
                    CartActivity.calculatePrice();
                }
            }

            public void onClick(View v) {

                if ((objectItem.getQuantity() ==1&&objectItem.getCategory()!=3)||objectItem.getQuantity()==1) {
                    new Builder(CartItemListAdapter.this.mContext).setTitle("Item Remove").setMessage("Do you want to remove this item from cart?").setIcon(R.drawable.ic_cart_red).setPositiveButton("Yes", new C07601()).setNegativeButton("No", null).show();
                    return;
                }
                else if((objectItem.getQuantity() ==5) && objectItem.getProduct_id()==75)
                {
                    new Builder(CartItemListAdapter.this.mContext).setTitle("Item Remove").setMessage("Do you want to remove this item from cart?").setIcon(R.drawable.ic_cart_red).setPositiveButton("Yes", new C07601()).setNegativeButton("No", null).show();
                    return;
                }
                else if((objectItem.getQuantity() ==5) && objectItem.getProduct_id()==81)
                {
                    new Builder(CartItemListAdapter.this.mContext).setTitle("Item Remove").setMessage("Do you want to remove this item from cart?").setIcon(R.drawable.ic_cart_red).setPositiveButton("Yes", new C07601()).setNegativeButton("No", null).show();
                    return;
                }
                else if((objectItem.getQuantity() ==5) && objectItem.getProduct_id()==77)
                {
                    new Builder(CartItemListAdapter.this.mContext).setTitle("Item Remove").setMessage("Do you want to remove this item from cart?").setIcon(R.drawable.ic_cart_red).setPositiveButton("Yes", new C07601()).setNegativeButton("No", null).show();
                    return;
                }
                else if((objectItem.getQuantity() ==5) && objectItem.getProduct_id()==82)
                {
                    new Builder(CartItemListAdapter.this.mContext).setTitle("Item Remove").setMessage("Do you want to remove this item from cart?").setIcon(R.drawable.ic_cart_red).setPositiveButton("Yes", new C07601()).setNegativeButton("No", null).show();
                    return;
                }

                else if((objectItem.getQuantity() ==1) && objectItem.getProduct_id()==79) {
                    new Builder(CartItemListAdapter.this.mContext).setTitle("Item Remove").setMessage("Do you want to remove this item from cart?").setIcon(R.drawable.ic_cart_red).setPositiveButton("Yes", new C07601()).setNegativeButton("No", null).show();
                    return;
                }

                if(objectItem.getCategory()==5){
                    objectItem.setQuantity(objectItem.getQuantity() -5);
                }else{
                    objectItem.setQuantity(objectItem.getQuantity() -1);

                }

                tv_qtn.setText(String.valueOf(objectItem.getQuantity()));
                CartActivity.calculatePrice();
            }
        });
        btn_remove.setOnClickListener(new OnClickListener() {

            /* renamed from: com.romilandroid.athos.adapters.CartItemListAdapter$3$1 */
            class C07621 implements DialogInterface.OnClickListener {
                C07621() {
                }

                public void onClick(DialogInterface dialog, int whichButton) {
                    for (int i = 0; i < GlobalMethods.cartList.size(); i++) {
                        if (((ItemData) GlobalMethods.cartList.get(i)).getProduct_id() == objectItem.getProduct_id()) {
                            GlobalMethods.cartList.remove(i);
                        }
                    }
                    CartActivity.calculatePrice();
                    CartActivity.adapter.notifyDataSetChanged();
                }
            }

            public void onClick(View v) {
                new Builder(CartItemListAdapter.this.mContext).setTitle("Item Remove").setMessage("Do you want to remove this item from cart?").setIcon(R.drawable.ic_cart_red).setPositiveButton("yes", new C07621()).setNegativeButton("No", null).show();
            }
        });
        return convertView;
    }
}
