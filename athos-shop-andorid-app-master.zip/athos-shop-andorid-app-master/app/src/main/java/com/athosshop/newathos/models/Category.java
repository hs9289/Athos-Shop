package com.athosshop.newathos.models;

public class Category {
    private String category_image;
    private String category_name;
    private String created_at;
    private int has_sub;
    private int id;

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategory_name() {
        return this.category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public int getHas_sub() {
        return this.has_sub;
    }

    public void setHas_sub(int has_sub) {
        this.has_sub = has_sub;
    }

    public String getCreated_at() {
        return this.created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getCategory_image() {
        return this.category_image;
    }

    public void setCategory_image(String category_image) {
        this.category_image = category_image;
    }
}
