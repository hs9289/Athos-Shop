package com.athosshop.newathos.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.athosshop.newathos.R;
import com.athosshop.newathos.activities.HomeActivity;
import com.athosshop.newathos.activities.MessageDilaog;
import com.athosshop.newathos.models.City;
import com.athosshop.newathos.models.Locality;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.UserSessionManager;

import java.util.ArrayList;

public class SelectCityDialog extends Dialog {
    ArrayAdapter<String> adapter_cities;
    ArrayAdapter<String> adapter_localities;
    Button cancel;
    ArrayList<String> citiesList = new ArrayList();
    int city = 0;
    Context context;
    ArrayList<String> localitiesList = new ArrayList();
    int locality = 0;
    Button ok;
    UserSessionManager sessionManager;
    Spinner spinner_city;
    Spinner spinner_locality;


    public SelectCityDialog(@NonNull Context context) {
        super(context);
        this.context = context;
        this.sessionManager = new UserSessionManager(context);
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(R.layout.select_city_dialog_layout);
        this.city = this.sessionManager.getUserCity();
        this.locality = this.sessionManager.getUserLocality();
        initUI();
        getCitiesList();
        bindSpinners();
        spinner_city.setSelection(city);

        this.spinner_city.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    try {
                        City city = GlobalMethods.citiesList.get(position - 1);
                        getLocalitiesList(city.getId());
                        sessionManager.setUserCity(city.getId());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

//                    if (position == 2) {
//                        MessageDilaog messageDilaog = new MessageDilaog(getContext());
//                        messageDilaog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
//                        messageDilaog.show();
//
//                    }
//                    if (position == 4) {
//                        MessageDilaog messageDilaog = new MessageDilaog(getContext());
//                        messageDilaog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
//                        messageDilaog.show();
//
//
//                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        this.spinner_locality.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    try {
                        int localityId = GlobalMethods.getLocalityIdByName(spinner_locality.getSelectedItem().toString());
                        SelectCityDialog.this.sessionManager.setUserLocality(localityId);
                        HomeActivity.tv_city.setText(spinner_locality.getSelectedItem().toString());
                        HomeActivity.Locality = localityId;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
//        findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                SelectCityDialog.this.dismiss();
//            }
//        });
        findViewById(R.id.ok).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HomeActivity.tv_city.setText(GlobalMethods.getLocalityNameById(SelectCityDialog.this.sessionManager.getUserLocality()));
                SelectCityDialog.this.dismiss();
            }
        });
    }

    void initUI() {
        this.spinner_city = (Spinner) findViewById(R.id.spinner_city);
        this.spinner_locality = (Spinner) findViewById(R.id.spinner_locality);
    }

    void getCitiesList() {
        try {
            this.citiesList.clear();
            this.citiesList.add("Select City");
            if (GlobalMethods.citiesList.size() > 0) {
                for (int i = 0; i < GlobalMethods.citiesList.size(); i++) {
                    this.citiesList.add((GlobalMethods.citiesList.get(i)).getLocation_name());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void getLocalitiesList(int cid) {
        try {
            this.localitiesList.clear();
            this.localitiesList.add("Select Locality");
//            if (cid == 1 || cid == 3 || cid == 2 || cid == 4) {
                if (GlobalMethods.localitiesList.size() > 0) {
                    for (int i = 0; i < GlobalMethods.localitiesList.size(); i++) {
                        Locality locality = GlobalMethods.localitiesList.get(i);
                        if (locality.getLocation_id() == cid) {
                            this.localitiesList.add(locality.getLocality_name());
                        }
                    }
//                }
            }
            if (this.adapter_localities != null) {
                this.adapter_localities.notifyDataSetChanged();
            }
            if (this.locality != 0) {
                selectLocality(this.locality);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void selectLocality(int lid) {
        int i = 0;
        while (i < this.localitiesList.size()) {
            try {
                if ((localitiesList.get(i)).equals(GlobalMethods.getLocalityNameById(lid))) {
                    this.spinner_locality.setSelection(i);
                    this.locality = 0;
                    break;
                }
                i++;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    void bindSpinners() {
        this.adapter_cities = new ArrayAdapter(this.context, R.layout.vendor_spinner_layout, this.citiesList);
        this.adapter_cities.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.spinner_city.setAdapter(this.adapter_cities);
        this.adapter_localities = new ArrayAdapter(this.context, R.layout.vendor_spinner_layout, this.localitiesList);
        this.adapter_localities.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.spinner_locality.setAdapter(this.adapter_localities);
    }
}
