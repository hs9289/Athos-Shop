package com.athosshop.newathos.activities;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.models.GeneralOutput;
import com.athosshop.newathos.models.ItemData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditProductDetailsActivity extends AppCompatActivity {
    ImageView iv_productImage;
    String productDescription;
    String productImage;
    String productName;
    int productId;
    float productPrice;
    TextView tv_productDescription;
    TextView tv_productTitle;
    EditText et_amount;
    Context context;
    API api;
    Button update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_product_details);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initUI();
        if (getIntent() != null) {
            this.productName = getIntent().getExtras().getString("ProductTitle");
            this.productDescription = getIntent().getExtras().getString("ProductDescription");
            this.productImage = getIntent().getExtras().getString("ProductImage");
            this.productPrice = getIntent().getExtras().getFloat("ProductPrice");
            this.productId = getIntent().getExtras().getInt("ProductId",0);
        }
        bindUI();

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ItemData itemData=new ItemData();
                itemData.setPrice(productPrice);
                itemData.setProduct_id(productId);
                itemData.setProduct_name(productName);
                itemData.setDescription(productDescription);

                if(et_amount.getText().toString().isEmpty()){
                    Toast.makeText(context,"Please enter product price",Toast.LENGTH_SHORT).show();
                }else{
                    try {
                        float product_price = Float.parseFloat(et_amount.getText().toString());
                        itemData.setPrice(product_price);
                        RetroCallForProductDetails(itemData);
                    } catch (Exception e) {
                        e.printStackTrace();
                        et_amount.setText("");
                        Toast.makeText(context,"Please enter valid product price",Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() != 16908332) {
            return super.onOptionsItemSelected(item);
        }
        onBackPressed();
        return true;
    }

    void initUI() {
        context=EditProductDetailsActivity.this;
        api=GlobalMethods.getAPI(context);
        this.iv_productImage = (ImageView) findViewById(R.id.iv_productImage);
        this.et_amount = findViewById(R.id.et_amount);
        this.tv_productTitle = (TextView) findViewById(R.id.tv_productTitle);
        this.tv_productDescription = (TextView) findViewById(R.id.tv_productDescription);
        update=findViewById(R.id.update);
    }

    void bindUI() {
        this.tv_productTitle.setText(this.productName);
        this.tv_productDescription.setText(this.productDescription);
        this.et_amount.setText(""+productPrice);
        RequestManager with = Glide.with(getApplicationContext());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(GlobalMethods.BaseUrl);
        stringBuilder.append(this.productImage);
        with.load(stringBuilder.toString()).placeholder(R.drawable.demo).dontAnimate().into(this.iv_productImage);
    }

    public void RetroCallForProductDetails(ItemData itemData) {
        try {
            if (GlobalMethods.isConnectedToInternet(getApplicationContext(), false)) {
                GlobalMethods.ShowDialog(context);
                this.api.update_item_details(itemData).enqueue(new Callback<GeneralOutput>() {
                    public void onResponse(Call<GeneralOutput> call, Response<GeneralOutput> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            if(response.body().isStatus()){
                                onBackPressed();
                            }
                        }
                        GlobalMethods.hideDialog();
                    }

                    public void onFailure(Call<GeneralOutput> call, Throwable t) {
                        Toast.makeText(context, "There was an error", Toast.LENGTH_SHORT).show();
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
        }
    }
}
