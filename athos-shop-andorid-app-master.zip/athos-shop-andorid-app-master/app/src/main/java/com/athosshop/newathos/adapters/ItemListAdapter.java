package com.athosshop.newathos.adapters;

import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.athosshop.newathos.activities.HomeActivity;
import com.bumptech.glide.Glide;
import com.athosshop.newathos.R;
import com.athosshop.newathos.activities.CartActivity;
import com.athosshop.newathos.activities.ProductDescriptionActivity;
import com.athosshop.newathos.models.ItemData;
import com.athosshop.newathos.utils.GlobalMethods;

import java.util.ArrayList;

public class ItemListAdapter extends RecyclerView.Adapter<ItemListAdapter.ViewHolder> {
    ArrayList<ItemData> data;
    int layoutResourceId;
    Context mContext;

    public ItemListAdapter(Context mContext, int layoutResourceId, ArrayList<ItemData> data) {
        //super(mContext, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.mContext = mContext;
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        View listItem = layoutInflater.inflate(layoutResourceId, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int i) {
        final ItemData objectItem = this.data.get(i);
        try {
            System.out.println("Data ---"+GlobalMethods.BaseUrlPic + objectItem.getProduct_image());
            viewHolder.tv_itemname.setText(objectItem.getProduct_name());
            //viewHolder.tv_itemprice.setText("Rs. "+objectItem.getPrice()+"/Kg");
            if (objectItem.getCategory() == 2) {
                viewHolder.tv_itemprice.setText("₹ " + objectItem.getPrice() + "/Kg");
            } else {
                viewHolder.tv_itemprice.setText("₹ " + objectItem.getPrice() + "/Kg");
            }

//            if (objectItem.getDescription().length() > 60) {
//                viewHolder.tv_itemdes.setText(objectItem.getDescription().substring(0, 60)+"...");
//            }else {
//                viewHolder.tv_itemdes.setText(objectItem.getDescription());
//            }

            if (objectItem.getProduct_image() != null) {
                Glide.with(this.mContext).load(GlobalMethods.BaseUrlPic + objectItem.getProduct_image()).placeholder(R.drawable.demo).dontAnimate().into(viewHolder.iv_item_image);
            }
            boolean itemContains = false;
            while (i < GlobalMethods.cartList.size()) {
                if ((GlobalMethods.cartList.get(i)).getProduct_id() == objectItem.getProduct_id()) {
                    itemContains = true;
                }
                i++;
            }
            if (itemContains) {
                viewHolder.btn_add.setBackgroundResource(R.drawable.button_background_disable);
                viewHolder.btn_add.setTextColor(ContextCompat.getColor(mContext, R.color.black));
            } else {
                viewHolder.btn_add.setBackgroundResource(R.drawable.button_background_enable);
                viewHolder.btn_add.setTextColor(ContextCompat.getColor(mContext, R.color.white));
            }


            viewHolder.btn_add.setOnClickListener(new View.OnClickListener() {


                public void onClick(View v) {
                    boolean itemContains1 = false;
                    for (int i = 0; i < GlobalMethods.cartList.size(); i++) {
                        if ((GlobalMethods.cartList.get(i)).getProduct_id() == objectItem.getProduct_id()) {
                            itemContains1 = true;
                        }
                    }
                    if (itemContains1) {
                        new Builder(ItemListAdapter.this.mContext).setTitle("Item Remove").setMessage("Do you want to remove this item from cart?").setIcon(R.drawable.ic_cart_red).setPositiveButton("Yes", new OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                for (int i = 0; i < GlobalMethods.cartList.size(); i++) {
                                    if ((GlobalMethods.cartList.get(i)).getProduct_id() == objectItem.getProduct_id()) {
                                        GlobalMethods.cartList.remove(i);
                                    }
                                }
                                viewHolder.btn_add.setBackgroundResource(R.drawable.button_background_enable);
                                viewHolder.btn_add.setTextColor(ContextCompat.getColor(mContext, R.color.white));
                            }
                        }).setNegativeButton("No", null).show();
                    } else {
                        if (HomeActivity.Locality != 0) {
                            if (objectItem.getCategory() == 5) {
                                objectItem.setQuantity(5);
                            } else {
                                objectItem.setQuantity(1);
                            }

                            GlobalMethods.cartList.add(objectItem);
                            viewHolder.btn_add.setBackgroundResource(R.drawable.button_background_disable);
                            viewHolder.btn_add.setTextColor(ContextCompat.getColor(mContext, R.color.black));
                            ItemListAdapter.this.mContext.startActivity(new Intent(ItemListAdapter.this.mContext, CartActivity.class));
                        } else {
                            Toast.makeText(mContext, "Please Select Location", Toast.LENGTH_SHORT).show();
                        }

                    }

                }
            });
            viewHolder.mainLayout.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent intent = new Intent(ItemListAdapter.this.mContext, ProductDescriptionActivity.class);
                    intent.putExtra("ProductTitle", objectItem.getProduct_name());
                    intent.putExtra("ProductDescription", objectItem.getDescription());
                    intent.putExtra("ProductImage", objectItem.getProduct_image());
                    intent.putExtra("ProductPrice", objectItem.getPrice());
                    intent.putExtra("Product", objectItem);
                    intent.putExtra("isLocalitySet", HomeActivity.Locality != 0 ? 1 : 0);
                    ItemListAdapter.this.mContext.startActivity(intent);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView iv_item_image;
        public TextView tv_itemname, tv_itemdes, tv_itemprice;
        public Button btn_add;
        public RelativeLayout mainLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            iv_item_image = itemView.findViewById(R.id.iv_item_image);
            tv_itemname = itemView.findViewById(R.id.tv_itemname);
//            tv_itemdes = itemView.findViewById(R.id.item_des);
            tv_itemprice = itemView.findViewById(R.id.tv_itemprice);
            btn_add = itemView.findViewById(R.id.btn_add);
            mainLayout = itemView.findViewById(R.id.mainLayout);
        }
    }
}
