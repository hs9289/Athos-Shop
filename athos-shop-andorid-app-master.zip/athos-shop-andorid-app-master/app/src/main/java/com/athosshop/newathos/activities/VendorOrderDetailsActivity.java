package com.athosshop.newathos.activities;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.dialogs.EnterPinVendorDialog;
import com.athosshop.newathos.dialogs.MyDialogListener;
import com.athosshop.newathos.models.GeneralOutput;
import com.athosshop.newathos.models.VendorOrdersData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VendorOrderDetailsActivity extends AppCompatActivity {
    TextView tv_orderid,tv_order_datetime,tv_orderstatus,tv_itemname,tv_itemqtn,tv_itemprice,tv_ordertype,
            tv_deladdress,tv_deldate,tv_deltime,tv_orderpin;
    VendorOrdersData obj;
    Button complete;
    Context context;
    API api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_order_details);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        initUI();

        obj = (VendorOrdersData) getIntent().getSerializableExtra("VendorOrdersData");

        if(obj!=null){
            bindUI();
        }

        complete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EnterPinVendorDialog dialog = new EnterPinVendorDialog(VendorOrderDetailsActivity.this);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dialog.show();
                dialog.setListener(new MyDialogListener() {
                    @Override
                    public void userSelectedValue(String value) {
                        if(value!=null && !value.equals("")){
                            if(value.equals(obj.getOrder_pin())){
                                RetroCallForUpdateOrderItemStatus(Integer.parseInt(obj.getOrder_details_id()));
                            }else{
                                Toast.makeText(VendorOrderDetailsActivity.this,"Wrong pin",Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }

        return super.onOptionsItemSelected(item);
    }

    void initUI(){
        context=VendorOrderDetailsActivity.this;
        api=GlobalMethods.getAPI(context);
        tv_orderid=findViewById(R.id.tv_orderid);
        tv_order_datetime=findViewById(R.id.tv_order_datetime);
        tv_orderstatus=findViewById(R.id.tv_orderstatus);
        tv_itemname=findViewById(R.id.tv_itemname);
        tv_itemqtn=findViewById(R.id.tv_itemqtn);
        tv_itemprice=findViewById(R.id.tv_itemprice);
        tv_ordertype=findViewById(R.id.tv_ordertype);
        tv_deladdress=findViewById(R.id.tv_deladdress);
        tv_deldate=findViewById(R.id.tv_deldate);
        tv_deltime=findViewById(R.id.tv_deltime);
        tv_orderpin=findViewById(R.id.tv_orderpin);
        complete=findViewById(R.id.complete);
    }

    void bindUI(){
        if(obj!=null){
            tv_orderid.setText(obj.getOrder_id());
            tv_order_datetime.setText(obj.getCreated_at());
            tv_itemname.setText(obj.getProduct_name());
            tv_itemqtn.setText(String.valueOf(obj.getQuantity()));
            tv_itemprice.setText(String.valueOf(obj.getPrice()));
            tv_deladdress.setText(obj.getDelivery_address());
            tv_deldate.setText(obj.getDelivery_date());
            tv_deltime.setText(obj.getDelivery_time());
            tv_orderpin.setText(obj.getOrder_pin());

            if (obj.getItem_status() == 0) {
                tv_orderstatus.setText("NA");
                tv_orderstatus.setTextColor(getResources().getColor(R.color.small_text_color));
                complete.setVisibility(View.VISIBLE);
            }else if (obj.getItem_status() == 1) {
                tv_orderstatus.setText("Pending");
                tv_orderstatus.setTextColor(getResources().getColor(R.color.blue));
                complete.setVisibility(View.VISIBLE);
            } else if (obj.getItem_status() == 2) {
                tv_orderstatus.setText("Delivered");
                tv_orderstatus.setTextColor(getResources().getColor(R.color.green));
                complete.setVisibility(View.GONE);
            } else if (obj.getItem_status() == 3) {
                tv_orderstatus.setText("Cancelled");
                tv_orderstatus.setTextColor(getResources().getColor(R.color.red));
                complete.setVisibility(View.GONE);
            }

            if (obj.getItem_status() == 1) {
                tv_ordertype.setText("Cash");
            }else if (obj.getItem_status() == 2) {
                tv_ordertype.setText("Online");
            }else{
                tv_ordertype.setText("NA");
            }

        }

    }

    public void RetroCallForUpdateOrderItemStatus(int order_details_id) {
        try {
            if (GlobalMethods.isConnectedToInternet(this.context, false)) {
                GlobalMethods.ShowDialog(this.context);
                this.api.update_order_item_status(order_details_id).enqueue(new Callback<GeneralOutput>() {
                    public void onResponse(Call<GeneralOutput> call, Response<GeneralOutput> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            if(response.body().isStatus()){
                                onBackPressed();
                            }
                            Toast.makeText(context,response.body().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                        GlobalMethods.hideDialog();
                    }

                    public void onFailure(Call<GeneralOutput> call, Throwable t) {
                        Toast.makeText(context, "There was an error", Toast.LENGTH_SHORT).show();
                        GlobalMethods.hideDialog();
                    }
                });
            }
        } catch (Exception e) {
            GlobalMethods.hideDialog();
        }
    }
}
