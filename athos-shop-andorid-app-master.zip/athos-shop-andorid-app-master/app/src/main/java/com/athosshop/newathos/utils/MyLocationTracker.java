package com.athosshop.newathos.utils;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import com.sandrios.sandriosCamera.internal.utils.DateTimeUtils;
import java.util.List;
import java.util.Locale;

public class MyLocationTracker extends Service implements LocationListener {
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 100;
    private static long MIN_TIME_BW_UPDATES = DateTimeUtils.MINUTE;
    private static final int REQUEST_CODE_PERMISSION = 2;
    public String address;
    boolean canGetLocation;
    public String cityName;
    public String countryCode;
    public String countryName;
    public String ipAddress;
    boolean isGPSEnabled;
    boolean isNetworkEnabled;
    double latitude;
    Location location;
    protected LocationManager locationManager;
    double longitude;
    private Context mContext;
    private String mPermission = "android.permission.ACCESS_FINE_LOCATION";
    public String macAddress;
    public String state;
    public String zip;

    public MyLocationTracker(Context ctx) {
        this.mContext = ctx;
        this.isGPSEnabled = false;
        this.isNetworkEnabled = false;
        this.canGetLocation = false;
        getLocation();
        getAddress(this.latitude, this.longitude);
    }

    @SuppressLint({"MissingPermission"})
    public Location getLocation() {
        try {
            this.locationManager = (LocationManager) this.mContext.getSystemService(Context.LOCATION_SERVICE);
            this.isGPSEnabled = this.locationManager.isProviderEnabled("gps");
            this.isNetworkEnabled = this.locationManager.isProviderEnabled("network");
            if (!this.isGPSEnabled) {
                if (!this.isNetworkEnabled) {
                    return this.location;
                }
            }
            this.canGetLocation = true;
            if (this.isNetworkEnabled) {
                this.locationManager.requestLocationUpdates("network", MIN_TIME_BW_UPDATES, 100.0f, this);
                Log.d("Network", "Network");
                if (this.locationManager != null) {
                    this.location = this.locationManager.getLastKnownLocation("network");
                    if (this.location != null) {
                        this.latitude = this.location.getLatitude();
                        this.longitude = this.location.getLongitude();
                    }
                }
            }
            if (!this.isGPSEnabled || this.location != null) {
                return this.location;
            }
            this.locationManager.requestLocationUpdates("gps", MIN_TIME_BW_UPDATES, 100.0f, this);
            Log.d("GPS Enabled", "GPS Enabled");
            if (this.locationManager != null) {
                this.location = this.locationManager.getLastKnownLocation("gps");
                if (this.location != null) {
                    this.latitude = this.location.getLatitude();
                    this.longitude = this.location.getLongitude();
                }
            }
            return this.location;
        } catch (Exception var2) {
            var2.printStackTrace();
            return null;
        }
    }

    public double getLatitude() {
        Location location = this.location;
        if (location != null) {
            this.latitude = location.getLatitude();
        }
        return this.latitude;
    }

    public double getLongitude() {
        Location location = this.location;
        if (location != null) {
            this.longitude = location.getLongitude();
        }
        return this.longitude;
    }

    public boolean canGetLocation() {
        return this.canGetLocation;
    }

    public void onLocationChanged(Location location) {
        Location location2 = this.location;
        if (location2 != null) {
            this.latitude = location2.getLatitude();
            this.longitude = this.location.getLongitude();
        }
    }

    public void onProviderDisabled(String provider) {
    }

    public void onProviderEnabled(String provider) {
    }

    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    public IBinder onBind(Intent arg0) {
        return null;
    }

    public void onCreate() {
        Log.d("OnCreate", "Service OnCreate Start");
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public String getAddress(double lat, double lon) {
        String add = "";
        try {
            List<Address> addresses = new Geocoder(this.mContext, Locale.getDefault()).getFromLocation(lat, lon, 1);
            this.address = ((Address) addresses.get(0)).getAddressLine(0);
            this.zip = ((Address) addresses.get(0)).getPostalCode();
            this.cityName = ((Address) addresses.get(0)).getLocality();
            this.countryCode = ((Address) addresses.get(0)).getCountryCode();
            this.countryName = ((Address) addresses.get(0)).getCountryName();
            this.state = ((Address) addresses.get(0)).getAdminArea();
            return this.address;
        } catch (Exception var3) {
            System.out.println("------------->Exception");
            var3.printStackTrace();
            return add;
        }
    }

    @SuppressLint({"MissingPermission"})
    public Location getLastKnownLocation() {
        return this.locationManager.getLastKnownLocation("network");
    }
}
