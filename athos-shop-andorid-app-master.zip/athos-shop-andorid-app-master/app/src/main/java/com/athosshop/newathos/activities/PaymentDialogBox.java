package com.athosshop.newathos.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.athosshop.newathos.R;
import com.athosshop.newathos.utils.UserSessionManager;

public class PaymentDialogBox extends AppCompatActivity {
    UserSessionManager sessionManager;

    Button cash, online;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_payment_type_dialog_layout);

        cash = findViewById(R.id.cod);
        online = findViewById(R.id.online);


        cash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//
///                SelectPaymentTypeDialog dialog = new SelectPaymentTypeDialog(CheckoutActivity.this);
//                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
//                dialog.show();
//                dialog.setListener(new MyDialogListener() {
//                    @Override
//                  /  public void userSelectedValue(String value) {
//                        if(value!=null && !value.equals("")){
//                            RetroCallForUploadOrder(String.valueOf(getOrderArray()),
//                                    sessionManager.getUserId(),
//                                    CartActivity.totalAmount,
//                                    et_address.getText().toString(),
//                                    tv_datetime.getText().toString(),cityId,getOrderPin(),
//                                    value);
//                        }
//                    }
//                });
//            }
//}
//
//            }
//        });
//    }
//}/
//

            }

        });
    }
}

