package com.athosshop.newathos.models;

import java.util.ArrayList;

public class CommonData {
    private ArrayList<Category> categories;
    private ArrayList<City> cities;
    private ArrayList<Locality> localities;
    private ArrayList<SubCategory> sub_categories;

    public ArrayList<City> getCities() {
        return this.cities;
    }

    public void setCities(ArrayList<City> cities) {
        this.cities = cities;
    }

    public ArrayList<Locality> getLocalities() {
        return this.localities;
    }

    public void setLocalities(ArrayList<Locality> localities) {
        this.localities = localities;
    }

    public ArrayList<Category> getCategories() {
        return this.categories;
    }

    public void setCategories(ArrayList<Category> categories) {
        this.categories = categories;
    }

    public ArrayList<SubCategory> getSub_categories() {
        return this.sub_categories;
    }

    public void setSub_categories(ArrayList<SubCategory> sub_categories) {
        this.sub_categories = sub_categories;
    }
}
