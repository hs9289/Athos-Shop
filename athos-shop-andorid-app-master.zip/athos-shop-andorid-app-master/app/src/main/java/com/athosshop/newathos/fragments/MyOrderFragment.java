package com.athosshop.newathos.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.athosshop.newathos.R;
import com.athosshop.newathos.activities.OrderDetailActivity;
import com.athosshop.newathos.adapters.ItemListHistoryAdapter;
import com.athosshop.newathos.models.OrdersData;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.UserSessionManager;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyOrderFragment extends Fragment {
    API api;
    ArrayList<OrdersData> arrayList = new ArrayList();
    Context context;
    ListView listView;
    UserSessionManager sessionManager;

    /* renamed from: com.romilandroid.athos.fragments.MyOrderFragment$1 */
    class C07791 implements Callback<ArrayList<OrdersData>> {
        C07791() {
        }

        public void onResponse(Call<ArrayList<OrdersData>> call, Response<ArrayList<OrdersData>> response) {
            if (response.isSuccessful() && response.body() != null) {
                if (((ArrayList) response.body()).size() > 0) {
                    MyOrderFragment.this.bindListUI((ArrayList) response.body());
                } else {
                    Toast.makeText(MyOrderFragment.this.context, "Product not available", 0).show();
                }
            }
            GlobalMethods.hideDialog();
        }

        public void onFailure(Call<ArrayList<OrdersData>> call, Throwable t) {
            Toast.makeText(MyOrderFragment.this.context, "There was an error", 0).show();
            GlobalMethods.hideDialog();
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_order, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI(view);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                OrdersData ordersData = arrayList.get(position);
                Intent intent = new Intent(getActivity(), OrderDetailActivity.class);
                intent.putExtra("OrderId",ordersData.getId());
                startActivity(intent);
            }
        });
        RetroCallForGetAllOrders(this.sessionManager.getUserId());
    }

    void initUI(View view) {
        this.context = getActivity();
        this.api = GlobalMethods.getAPI(this.context);
        this.sessionManager = new UserSessionManager(this.context);
        this.listView = (ListView) view.findViewById(R.id.listView);
    }

    void bindListUI(ArrayList<OrdersData> data) {
        this.arrayList = data;
        this.listView.setAdapter(new ItemListHistoryAdapter(this.context, R.layout.order_history_list_item, this.arrayList));
    }

    public void RetroCallForGetAllOrders(int userid) {
        try {
            if (GlobalMethods.isConnectedToInternet(this.context, false)) {
                GlobalMethods.ShowDialog(this.context);
                this.api.get_orders_list(userid).enqueue(new C07791());
            }
        } catch (Exception e) {
        }
    }
}
