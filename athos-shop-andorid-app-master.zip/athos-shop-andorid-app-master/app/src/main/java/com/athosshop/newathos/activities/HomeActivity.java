package com.athosshop.newathos.activities;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.BottomNavigationView.OnNavigationItemSelectedListener;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.*;
import com.athosshop.newathos.R;
import com.athosshop.newathos.dialogs.SelectCityDialog;
import com.athosshop.newathos.fragments.HomeFragment;
import com.athosshop.newathos.fragments.MoreFragment;
import com.athosshop.newathos.fragments.MyOrderFragment;
import com.athosshop.newathos.fragments.ProfileFragment;
import com.athosshop.newathos.utils.BottomNavigationViewHelper;
import com.athosshop.newathos.utils.GlobalMethods;
import com.athosshop.newathos.utils.UserSessionManager;
import com.facebook.appevents.AppEventsConstants;
import com.facebook.appevents.AppEventsLogger;

public class HomeActivity extends AppCompatActivity implements OnNavigationItemSelectedListener {
    public static TextView tv_city;
    int backButtonCount = 0;
    UserSessionManager sessionManager;
    public static int Locality = 0;
    Context context;
    private final String TAG = HomeActivity.class.getSimpleName();
    private InterstitialAd interstitialAd;

    /* renamed from: com.romilandroid.athos.activities.HomeActivity$1 */
    class C07311 implements OnClickListener {
        C07311() {
        }

        public void onClick(View v) {
            SelectCityDialog dialog = new SelectCityDialog(HomeActivity.this);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.show();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        this.sessionManager = new UserSessionManager(this);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(this);
        loadFragment(new HomeFragment());
        BottomNavigationViewHelper.disableShiftMode(navigation);
        ActionBar mActionBar = getSupportActionBar();
        mActionBar.setDisplayShowHomeEnabled(false);
        mActionBar.setDisplayShowTitleEnabled(false);
        mActionBar.setCustomView(LayoutInflater.from(this).inflate(R.layout.custom_actionbar, null));
        mActionBar.setDisplayShowCustomEnabled(true);
        tv_city = (TextView) findViewById(R.id.tv_city);
        tv_city.setOnClickListener(new C07311());
        HomeActivity.Locality = sessionManager.getUserLocality();
       // facbookpixel();
//        try {
//            PackageInfo info = getPackageManager().getPackageInfo(
//                    getPackageName(),
//                    PackageManager.GET_SIGNATURES);
//            for (Signature signature : info.signatures) {
//                MessageDigest md = MessageDigest.getInstance("SHA");
//                md.update(signature.toByteArray());
//                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
//            }
//        } catch (PackageManager.NameNotFoundException e) {
//
//        } catch (NoSuchAlgorithmException e) {
//
//        }

//
//        // Find the Ad Container
//        LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);
//
//        // Add the ad view to your activity layout
//        adContainer.addView(adView);
//
//        // Request an ad
//        adView.loadAd();
    }


    private boolean loadFragment(Fragment fragment) {
        if (fragment == null) {
            return false;
        }
        getSupportFragmentManager().beginTransaction()
//                .setCustomAnimations(R.anim.slide_in_left,R.anim.slide_out_left )
                .replace(R.id.fragment_container, fragment).commit();
        return true;
    }

    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        switch (item.getItemId()) {
            case R.id.history:
                fragment = new MyOrderFragment();
                break;
            case R.id.home:
                fragment = new HomeFragment();
                break;
            case R.id.more:
                fragment = new MoreFragment();
                break;
            case R.id.profile:
                fragment = new ProfileFragment();
                break;
            default:
                break;
        }
        return loadFragment(fragment);
    }

    protected void onResume() {
        super.onResume();
        if (this.sessionManager.getUserCity() != 0) {
            tv_city.setText(GlobalMethods.getLocalityNameById(this.sessionManager.getUserLocality()));
        }
    }

    public void onBackPressed() {
        if (this.backButtonCount >= 1) {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return;
        }
        Toast.makeText(this, "Press Back button Again.", Toast.LENGTH_SHORT).show();
        this.backButtonCount++;


    }

    public void facbookpixel()
    {

        AppEventsLogger logger = AppEventsLogger.newLogger(this);
        logger.logEvent(AppEventsConstants.EVENT_NAME_ACTIVATED_APP);
        Bundle params = new Bundle();
        params.putString(AppEventsConstants.EVENT_PARAM_CONTENT_TYPE,"product");
        params.putString(AppEventsConstants.EVENT_PARAM_CURRENCY, "USD");
        params.putString(AppEventsConstants.EVENT_PARAM_CONTENT_TYPE, "product");
        params.putString(AppEventsConstants.EVENT_PARAM_CONTENT, "[{\"id\": \"1234\", \"quantity\": 2}, {\"id\": \"5678\", \"quantity\": 1}]");
        logger.logEvent(AppEventsConstants.EVENT_NAME_ACTIVATED_APP, 54.23, params);
        params.putString(AppEventsConstants.EVENT_PARAM_CURRENCY, "USD");
        params.putString(AppEventsConstants.EVENT_PARAM_CONTENT_TYPE, "product");
        params.putString(AppEventsConstants.EVENT_PARAM_CONTENT_ID, "HDFU-8452");
        logger.logEvent(AppEventsConstants.EVENT_NAME_ADDED_TO_CART,
                54.23, params); }}






