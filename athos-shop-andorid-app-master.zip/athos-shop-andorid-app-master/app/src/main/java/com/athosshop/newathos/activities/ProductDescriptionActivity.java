package com.athosshop.newathos.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.athosshop.newathos.models.ItemData;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.athosshop.newathos.R;
import com.athosshop.newathos.utils.GlobalMethods;

public class ProductDescriptionActivity extends AppCompatActivity {
    ImageView iv_productImage;
    String productDescription;
    String productImage;
    String productName;
    float productPrice;
    TextView tv_productDescription;
    TextView tv_productPrice;
    TextView tv_productTitle;
    ItemData item;
    Button btn_add;
    int isLocalitySet;
    Context mContext;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_description);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initUI();
        if (getIntent() != null) {
            this.productName = getIntent().getExtras().getString("ProductTitle");
            this.productDescription = getIntent().getExtras().getString("ProductDescription");
            this.productImage = getIntent().getExtras().getString("ProductImage");
            this.productPrice = getIntent().getExtras().getFloat("ProductPrice");
            this.item = (ItemData) getIntent().getSerializableExtra("Product");
            this.isLocalitySet = getIntent().getExtras().getInt("isLocalitySet");
        }
        bindUI();
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() != 16908332) {
            return super.onOptionsItemSelected(item);
        }
        onBackPressed();
        return true;
    }

    void initUI() {
        this.iv_productImage = (ImageView) findViewById(R.id.iv_productImage);
        this.tv_productPrice = (TextView) findViewById(R.id.tv_productPrice);
        this.tv_productTitle = (TextView) findViewById(R.id.tv_productTitle);
        this.tv_productDescription = (TextView) findViewById(R.id.tv_productDescription);
        this.btn_add = (Button) findViewById(R.id.btn_add);
    }

    void bindUI() {
        this.tv_productTitle.setText(this.productName+" - 1Kg");
        this.tv_productDescription.setText(this.productDescription);
        this.tv_productPrice.setText("₹ "+productPrice);
        RequestManager with = Glide.with(getApplicationContext());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(GlobalMethods.BaseUrlPic);
        stringBuilder.append(this.productImage);
        with.load(stringBuilder.toString()).placeholder(R.drawable.demo).dontAnimate().into(this.iv_productImage);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isLocalitySet != 0){

                    int index = 0;
                    for (int i = 0; i < GlobalMethods.cartList.size(); i++) {
                        if ((GlobalMethods.cartList.get(i)).getProduct_id() == item.getProduct_id()) {
                            index = i;
                        }
                    }
                    if (index != 0) {
                        (GlobalMethods.cartList.get(index)).setQuantity(((GlobalMethods.cartList.get(index)).getQuantity()) + 1);
                    } else {
                        item.setQuantity(1);
                        GlobalMethods.cartList.add(item);
                        Toast.makeText(getApplicationContext(), "Added to Cart", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), CartActivity.class));
                    }
                }else {
                    Toast.makeText(getApplicationContext(), "Please Select Location", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
