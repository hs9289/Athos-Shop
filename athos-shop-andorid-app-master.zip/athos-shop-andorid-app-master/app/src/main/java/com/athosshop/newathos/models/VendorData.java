package com.athosshop.newathos.models;

public class VendorData {
    private String aadhaar;
    private String aadhaar_pic;
    private int aadhaar_status;
    private String address;
    private String bank_account;
    private String bank_branch;
    private String bank_ifsc;
    private String bank_name;
    private int city;
    private String email;
    private String first_name;
    private String gst;
    private String fssai;
    private int id;
    private String last_name;
    private int locality;
    private String message;
    private String mobile;
    private String pan;
    private String pan_pic;
    private int pan_status;
    private boolean status;
    private int video_status;

    public VendorData(String first_name, String last_name, String email, String mobile, String address, int city, int locality, String bank_name, String bank_branch, String bank_account, String bank_ifsc, String gst, String fssai,int id) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.email = email;
        this.mobile = mobile;
        this.address = address;
        this.city = city;
        this.locality = locality;
        this.bank_name = bank_name;
        this.bank_branch = bank_branch;
        this.bank_account = bank_account;
        this.bank_ifsc = bank_ifsc;
        this.gst = gst;
        this.fssai = fssai;
        this.id = id;
    }

    public String getFirst_name() {
        return this.first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return this.last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return this.mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getCity() {
        return this.city;
    }

    public void setCity(int city) {
        this.city = city;
    }

    public int getLocality() {
        return this.locality;
    }

    public void setLocality(int locality) {
        this.locality = locality;
    }

    public String getAadhaar() {
        return this.aadhaar;
    }

    public void setAadhaar(String aadhaar) {
        this.aadhaar = aadhaar;
    }

    public String getPan() {
        return this.pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getBank_name() {
        return this.bank_name;
    }

    public void setBank_name(String bank_name) {
        this.bank_name = bank_name;
    }

    public String getBank_branch() {
        return this.bank_branch;
    }

    public void setBank_branch(String bank_branch) {
        this.bank_branch = bank_branch;
    }

    public String getBank_account() {
        return this.bank_account;
    }

    public void setBank_account(String bank_account) {
        this.bank_account = bank_account;
    }

    public String getBank_ifsc() {
        return this.bank_ifsc;
    }

    public void setBank_ifsc(String bank_ifsc) {
        this.bank_ifsc = bank_ifsc;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isStatus() {
        return this.status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAadhaar_pic() {
        return this.aadhaar_pic;
    }

    public void setAadhaar_pic(String aadhaar_pic) {
        this.aadhaar_pic = aadhaar_pic;
    }

    public String getPan_pic() {
        return this.pan_pic;
    }

    public void setPan_pic(String pan_pic) {
        this.pan_pic = pan_pic;
    }

    public int getAadhaar_status() {
        return this.aadhaar_status;
    }

    public void setAadhaar_status(int aadhaar_status) {
        this.aadhaar_status = aadhaar_status;
    }

    public int getPan_status() {
        return this.pan_status;
    }

    public void setPan_status(int pan_status) {
        this.pan_status = pan_status;
    }

    public int getVideo_status() {
        return this.video_status;
    }

    public void setVideo_status(int video_status) {
        this.video_status = video_status;
    }

    public String getGst() {
        return this.gst;
    }

    public void setGst(String gst) {
        this.gst = gst;
    }

    public String getFssai() {
        return fssai;
    }

    public void setFssai(String fssai) {
        this.fssai = fssai;
    }
}
