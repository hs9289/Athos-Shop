package com.athosshop.newathos.activities;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.Button;

import com.athosshop.newathos.R;


public class MessageDilaog extends Dialog {

    Button ok ,cancel;
    Context context;

    public MessageDilaog(@NonNull   Context   context) {
        super(context);
    }


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);

        setContentView(R.layout.message_custmon_layout);
        ok=findViewById(R.id.ok);
        cancel=findViewById(R.id.ok);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MessageDilaog.this.dismiss();
            }
        });

    }
    }





