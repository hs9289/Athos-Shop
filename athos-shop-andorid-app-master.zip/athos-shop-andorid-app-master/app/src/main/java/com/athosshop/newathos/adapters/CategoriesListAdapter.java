package com.athosshop.newathos.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.athosshop.newathos.R;
import com.athosshop.newathos.fragments.HomeFragment;
import com.athosshop.newathos.models.Category;
import com.athosshop.newathos.network.API;
import com.athosshop.newathos.utils.GlobalMethods;
import java.util.List;

public class CategoriesListAdapter extends Adapter<CategoriesListAdapter.MyViewHolder> {
    API api;
    private List<Category> categoriesList;
    Context mContext;

    public class MyViewHolder extends ViewHolder {
        ImageView iv_category_icon;
        public LinearLayout mainLayout;
        public TextView tv_category_name;

        public MyViewHolder(View view) {
            super(view);
            this.iv_category_icon = (ImageView) view.findViewById(R.id.iv_category_icon);
            this.tv_category_name = (TextView) view.findViewById(R.id.tv_category_name);
            this.mainLayout = (LinearLayout) view.findViewById(R.id.mainLayout);
        }
    }

    @NonNull
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.category_list_item, parent, false));
    }

    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
//        System.out.println("Category List _----- "+this.categoriesList.get(position).getCategory_name());
        final Category category = (Category) this.categoriesList.get(position);
        holder.tv_category_name.setText(category.getCategory_name());
        holder.mainLayout.setWeightSum(045f);
        if (category.getCategory_image() != null) {
            RequestManager with = Glide.with(this.mContext);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(GlobalMethods.BaseUrlPic);
            stringBuilder.append(category.getCategory_image());
            with.load(stringBuilder.toString()).placeholder(R.drawable.demo).dontAnimate().into(holder.iv_category_icon);
        }
        holder.mainLayout.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                HomeFragment.RetroCallForGetAllProductList(category.getId());
            }
        });
    }

    public int getItemCount() {
        return this.categoriesList.size();
    }

    public CategoriesListAdapter(List<Category> categoriesList, Context mContext) {
        this.categoriesList = categoriesList;
        this.mContext = mContext;
        this.api = GlobalMethods.getAPI(mContext);
    }
}
