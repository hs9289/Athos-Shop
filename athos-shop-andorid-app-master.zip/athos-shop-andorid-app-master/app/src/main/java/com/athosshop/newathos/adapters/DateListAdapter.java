package com.athosshop.newathos.adapters;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.athosshop.newathos.R;

import java.util.ArrayList;

public class DateListAdapter extends ArrayAdapter<String> {
    ArrayList<String> data;
    int layoutResourceId;
    Context mContext;

    public DateListAdapter(Context mContext, int layoutResourceId, ArrayList<String> data) {
        super(mContext, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.mContext = mContext;
        this.data = data;
    }

    @NonNull
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            try {
                convertView = ((Activity) this.mContext).getLayoutInflater().inflate(this.layoutResourceId, parent, false);
            } catch (Exception e) {
            }
        }
        ((TextView) convertView.findViewById(R.id.tv_date)).setText((String) this.data.get(position));
        return convertView;
    }
}
