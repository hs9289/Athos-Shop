package com.athosshop.newathos.ccavenue.utility;

public class Constants {
    public static final String WORKING_KEY = "B37BD760FC40EF0510409F4FA32784EE";//"7059E2BFA3002B36EAFCBE197CBDEE71";
    public static final String PARAMETER_SEP = "&";
	public static final String PARAMETER_EQUALS = "=";
	public static final String CURRENCY = "INR";
	public static final String MERCHANT_ID = "204607"; //"204607";
	public static final String ACCESS_CODE = "AVHU82GA81AW82UHWA"; //"AVHU82GA81AW82UHWA";
//	public static final String TRANS_URL = "https://test.ccavenue.com/transaction/initTrans";
	public static final String TRANS_URL = "https://secure.ccavenue.com/transaction/initTrans";
	public static final String REDIRECT_URL = "https://www.athosshop.com/api/athos_api/food_supply/ccavenue/ccavResponseHandler.php";//"https://www.athosshop.com/ccavenue/ccavResponseHandler.php";
	public static final String CANCEL_URL = "https://www.athosshop.com/api/athos_api/food_supply/ccavenue/ccavResponseHandler.php";//"https://www.athosshop.com/ccavenue/ccavResponseHandler.php";
	public static final String RSA_KEY_URL = "http://www.athosshop.com/api/athos_api/food_supply/ccavenue/GetRSA.php";//"https://www.athosshop.com/ccavenue/GetRSA.php";

	public static String BILLING_COUNTRY = "India";
	public static String BILLING_CITY = "Noida";
	public static String BILLING_STATE = "U.P.";
	public static String BILLING_EMAIL = "piyush0369@gmail.com";
	public static String BILLING_TEL = "9144601892";
	public static String BILLING_ADDRESS = "billing_address";
	public static String DELIVERY_COUNTRY = "India";
	public static String DELIVERY_CITY = "Noida";
	public static String DELIVERY_STATE = "U.P.";
	public static String DELIVERY_ADDRESS = "delivery_address";
	public static String DELIVERY_TEL = "9144601892";
}
