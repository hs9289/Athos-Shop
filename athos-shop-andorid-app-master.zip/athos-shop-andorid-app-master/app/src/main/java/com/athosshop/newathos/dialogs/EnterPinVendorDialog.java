package com.athosshop.newathos.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.EditText;

import com.athosshop.newathos.R;
import com.athosshop.newathos.utils.UserSessionManager;

public class EnterPinVendorDialog extends Dialog {
    Context context;
    UserSessionManager sessionManager;
    EditText et_pin;
    MyDialogListener listener;

    public EnterPinVendorDialog(@NonNull Context context) {
        super(context);
        this.context = context;
        this.sessionManager = new UserSessionManager(context);
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(R.layout.enter_pin_vendor_dialog_layout);

        et_pin=findViewById(R.id.et_pin);

        findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.userSelectedValue("");
                dismiss();
            }
        });
        findViewById(R.id.ok).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.userSelectedValue(et_pin.getText().toString());
                dismiss();
            }
        });
    }

    public MyDialogListener getListener() {
        return listener;
    }

    public void setListener(MyDialogListener listener) {
        this.listener = listener;
    }

}
